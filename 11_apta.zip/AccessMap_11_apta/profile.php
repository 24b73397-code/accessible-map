<?php
require_once 'includes/functions.php';
require_login(); // Жабық бетті қорғау!

$user = current_user();

$stmt_user = $pdo->prepare("SELECT user_id, full_name, email, role, created_at FROM Users WHERE user_id = ?");
$stmt_user->execute([$user['user_id']]);
$db_user = $stmt_user->fetch();

$stmt_places = $pdo->prepare("SELECT COUNT(*) FROM Places WHERE created_by = ?");
$stmt_places->execute([$user['user_id']]);
$my_places_count = (int)$stmt_places->fetchColumn();

$stmt_reviews = $pdo->prepare("SELECT COUNT(*) FROM Reviews WHERE user_id = ?");
$stmt_reviews->execute([$user['user_id']]);
$my_reviews_count = (int)$stmt_reviews->fetchColumn();

$stmt_favs = $pdo->prepare("SELECT COUNT(*) FROM Favorites WHERE user_id = ?");
$stmt_favs->execute([$user['user_id']]);
$my_favs_count = (int)$stmt_favs->fetchColumn();

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">ҚОРҒАЛҒАН БЕТ (REQUIRE_LOGIN)</span>
        <h1>Жеке кабинет</h1>
        <p class="small-muted">Бұл бет тек <code>session_start()</code> арқылы жүйеге кірген пайдаланушыларға қолжетімді.</p>
    </div>

    <div class="cards-3">
        <div class="info-card">
            <div class="icon-box">👤</div>
            <h3>Пайдаланушы деректері</h3>
            <p><strong>Аты-жөні:</strong> <?= h($db_user['full_name']) ?></p>
            <p><strong>Email:</strong> <?= h($db_user['email']) ?></p>
            <p><strong>Рөлі:</strong> <span class="pill-badge"><?= h($db_user['role']) ?></span></p>
            <p class="small-muted">Тіркелген уақыты: <?= h($db_user['created_at']) ?></p>
        </div>

        <div class="info-card">
            <div class="icon-box">📊</div>
            <h3>Белсенділік статистикасы</h3>
            <p><strong>Таңдаулы нысандар:</strong> <?= $my_favs_count ?></p>
            <p><strong>Қалдырған пікірлер:</strong> <?= $my_reviews_count ?></p>
            <p><strong>Қосқан нысандар:</strong> <?= $my_places_count ?></p>
        </div>

        <div class="info-card">
            <div class="icon-box">⚡</div>
            <h3>Жылдам әрекеттер</h3>
            <div class="stack-form">
                <a href="map.php" class="btn btn-primary">🗺️ Нысандар картасына өту</a>
                <a href="add_place.php" class="btn btn-outline">+ Жаңа нысан қосу</a>
                <a href="favorites.php" class="btn btn-outline">★ Таңдаулылар тізімі</a>
                <a href="logout.php" class="btn btn-outline" style="color:#a61b1b;border-color:#f5c2c2;">Жүйеден шығу</a>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
