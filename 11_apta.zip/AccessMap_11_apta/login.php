<?php
require_once 'includes/functions.php';

if (is_logged_in()) {
    redirect('profile.php');
}

$errors = [];
$email = '';

if (!empty($_SESSION['flash_error'])) {
    $errors[] = $_SESSION['flash_error'];
    unset($_SESSION['flash_error']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!valid_email($email)) {
        $errors[] = 'Жарамды электрондық пошта енгізіңіз.';
    }
    if ($password === '') {
        $errors[] = 'Құпия сөзді енгізіңіз.';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT user_id, full_name, email, password_hash, role FROM Users WHERE email = ?");
        $stmt->execute([$email]);
        $user_row = $stmt->fetch();

        if ($user_row && password_verify($password, $user_row['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'user_id'   => (int)$user_row['user_id'],
                'full_name' => $user_row['full_name'],
                'email'     => $user_row['email'],
                'role'      => $user_row['role']
            ];
            redirect('profile.php');
        } else {
            $errors[] = 'Электрондық пошта немесе құпия сөз қате.';
        }
    }
}

include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card">
        <span class="section-kicker">ҚОШ КЕЛДІҢІЗ!</span>
        <h1>Жүйеге кіру</h1>
        <p class="small-muted">MySQL дерекқоры және <code>password_verify()</code> арқылы аутентификация.</p>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?>
                    <div>• <?= h($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="login.php" class="stack-form">
            <label for="email">Электрондық пошта</label>
            <input id="email" type="email" name="email" required
                   value="<?= h($email) ?>" placeholder="example@mail.com">

            <label for="password">Құпия сөз</label>
            <input id="password" type="password" name="password" required
                   placeholder="Құпия сөз">

            <button type="submit" class="btn btn-primary btn-block">Кіру</button>
        </form>

        <p class="auth-switch">Аккаунтыңыз жоқ па? <a href="register.php">Тіркелу</a></p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
