<?php
require_once 'includes/functions.php';

$q = trim($_GET['q'] ?? '');
$category_id = filter_var($_GET['category'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$feature_id = filter_var($_GET['feature'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$selected_id = filter_var($_GET['place'] ?? '', FILTER_VALIDATE_INT) ?: 0;

$review_errors = [];
$review_success = '';

// POST әрекеттері: тек авторизацияланған пайдаланушыларға
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_login();
    $user_id = (int)current_user()['user_id'];
    $action = $_POST['action'] ?? '';
    $target_place_id = filter_var($_POST['place_id'] ?? '', FILTER_VALIDATE_INT) ?: 0;
    $selected_id = $target_place_id;

    if ($action === 'toggle_favorite' && $target_place_id > 0) {
        $chk = $pdo->prepare("SELECT favorite_id FROM Favorites WHERE user_id = ? AND place_id = ?");
        $chk->execute([$user_id, $target_place_id]);
        if ($chk->fetch()) {
            $del = $pdo->prepare("DELETE FROM Favorites WHERE user_id = ? AND place_id = ?");
            $del->execute([$user_id, $target_place_id]);
        } else {
            $ins = $pdo->prepare("INSERT INTO Favorites (user_id, place_id) VALUES (?, ?)");
            $ins->execute([$user_id, $target_place_id]);
        }
    }

    if ($action === 'add_review' && $target_place_id > 0) {
        $rating = filter_var($_POST['rating'] ?? null, FILTER_VALIDATE_INT);
        $comment = trim($_POST['comment'] ?? '');

        if (!$rating || $rating < 1 || $rating > 5) {
            $review_errors[] = 'Баға 1 мен 5 аралығында болуы тиіс.';
        }
        if ($comment === '' || mb_strlen($comment) < 5) {
            $review_errors[] = 'Пікір мәтіні кемінде 5 таңбадан тұруы тиіс.';
        }

        if (empty($review_errors)) {
            $insRev = $pdo->prepare("INSERT INTO Reviews (user_id, place_id, rating, comment) VALUES (?, ?, ?, ?)");
            $insRev->execute([$user_id, $target_place_id, $rating, $comment]);
            $review_success = 'Пікіріңіз MySQL дерекқорына сәтті сақталды!';
        }
    }
}

// Санаттар мен ерекшеліктер тізімі
$categories = $pdo->query("SELECT category_id, category_name FROM Categories ORDER BY category_id")->fetchAll();
$all_features = $pdo->query("SELECT feature_id, feature_name FROM AccessibilityFeatures ORDER BY feature_id")->fetchAll();

// Нысандарды сүзгілеу сұранысы
$sql = "SELECT DISTINCT p.*, c.category_name
        FROM Places p
        LEFT JOIN Categories c ON p.category_id = c.category_id";
$params = [];
$where = [];

if ($feature_id > 0) {
    $sql .= " INNER JOIN PlaceFeatures pf ON p.place_id = pf.place_id AND pf.feature_id = ? AND pf.availability_status = 'available'";
    $params[] = $feature_id;
}

if ($q !== '') {
    $where[] = "(p.name LIKE ? OR p.address LIKE ? OR c.category_name LIKE ?)";
    $like = '%' . $q . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if ($category_id > 0) {
    $where[] = "p.category_id = ?";
    $params[] = $category_id;
}

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY p.place_id ASC";

$stmtPlaces = $pdo->prepare($sql);
$stmtPlaces->execute($params);
$filtered_places = $stmtPlaces->fetchAll();

// Әр нысанның қолжетімділік белгілерін жүктеу
$place_features_map = [];
$pf_rows = $pdo->query("SELECT pf.place_id, af.feature_name
                        FROM PlaceFeatures pf
                        INNER JOIN AccessibilityFeatures af ON pf.feature_id = af.feature_id
                        WHERE pf.availability_status = 'available'")->fetchAll();
foreach ($pf_rows as $r) {
    $place_features_map[(int)$r['place_id']][] = $r['feature_name'];
}

// Таңдалған нысан
$selected_place = null;
foreach ($filtered_places as $p) {
    if ((int)$p['place_id'] === $selected_id) {
        $selected_place = $p;
        break;
    }
}
if (!$selected_place && !empty($filtered_places)) {
    $selected_place = $filtered_places[0];
}

// Таңдалған нысанның пікірлері және таңдаулы мәртебесі
$place_reviews = [];
$is_fav = false;
if ($selected_place) {
    $sel_pid = (int)$selected_place['place_id'];
    $stmtRev = $pdo->prepare("SELECT r.*, u.full_name
                              FROM Reviews r
                              INNER JOIN Users u ON r.user_id = u.user_id
                              WHERE r.place_id = ?
                              ORDER BY r.created_at DESC, r.review_id DESC");
    $stmtRev->execute([$sel_pid]);
    $place_reviews = $stmtRev->fetchAll();

    if (is_logged_in()) {
        $stmtChkFav = $pdo->prepare("SELECT 1 FROM Favorites WHERE user_id = ? AND place_id = ?");
        $stmtChkFav->execute([current_user()['user_id'], $sel_pid]);
        $is_fav = (bool)$stmtChkFav->fetchColumn();
    }
}

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">КАРТА ЖӘНЕ MYSQL КАТАЛОГ</span>
        <h1>Қолжетімді нысандарды табыңыз</h1>
        <p class="muted-note">
            Деректер MySQL (<code>Places</code>, <code>Categories</code>, <code>PlaceFeatures</code>) кестелерінен PDO арқылы жүктеледі.
        </p>
    </div>

    <form method="get" action="map.php" class="filter-panel">
        <div class="filter-field">
            <label for="q">Атауы бойынша іздеу</label>
            <input id="q" type="text" name="q" value="<?= h($q) ?>" placeholder="Емхана, кітапхана...">
        </div>
        <div class="filter-field">
            <label for="category">Санат</label>
            <select id="category" name="category">
                <option value="">Барлық санаттар</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= (int)$cat['category_id'] ?>" <?= $category_id === (int)$cat['category_id'] ? 'selected' : '' ?>>
                        <?= h($cat['category_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-field">
            <label for="feature">Қолжетімділік</label>
            <select id="feature" name="feature">
                <option value="">Барлық нысандар</option>
                <?php foreach ($all_features as $feat): ?>
                    <option value="<?= (int)$feat['feature_id'] ?>" <?= $feature_id === (int)$feat['feature_id'] ? 'selected' : '' ?>>
                        <?= h($feat['feature_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-actions">
            <button type="submit" class="btn btn-primary">Іздеу</button>
            <a href="map.php" class="btn btn-outline">Тазарту</a>
        </div>
    </form>

    <div class="map-layout">
        <div class="places-column">
            <div class="list-header">
                <h3>Нысандар</h3>
                <span class="small-muted"><?= count($filtered_places) ?> нысан</span>
            </div>

            <?php if (empty($filtered_places)): ?>
                <div class="empty-box">Сұраныс бойынша нысан табылмады.</div>
            <?php else: ?>
                <?php foreach ($filtered_places as $p):
                    $pid = (int)$p['place_id'];
                    $p_feats = $place_features_map[$pid] ?? [];
                    $is_active = $selected_place && (int)$selected_place['place_id'] === $pid;
                    $link = 'map.php?' . http_build_query([
                        'q' => $q,
                        'category' => $category_id ?: '',
                        'feature' => $feature_id ?: '',
                        'place' => $pid
                    ]);
                ?>
                    <a href="<?= h($link) ?>" class="place-item <?= $is_active ? 'active' : '' ?>">
                        <div class="place-icon"><?= h($p['icon']) ?></div>
                        <div class="place-meta">
                            <strong><?= h($p['name']) ?></strong>
                            <span class="small-muted"><?= h($p['category_name']) ?> · <?= h($p['address']) ?></span>
                            <div class="mini-tags">
                                <?php if (in_array('Пандус', $p_feats, true)): ?>
                                    <span class="tag-ok">♿ Пандус бар</span>
                                <?php else: ?>
                                    <span class="tag-no">Пандус көрсетілмеген</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <span class="arrow">→</span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="map-board">
            <div class="board-label">ИНТЕРАКТИВТІ КАРТА МАКЕТІ</div>
            <div class="road road-1"></div>
            <div class="road road-2"></div>
            <div class="park-zone">🌳 Саябақ</div>

            <?php foreach ($filtered_places as $p):
                $pid = (int)$p['place_id'];
                $is_active = $selected_place && (int)$selected_place['place_id'] === $pid;
                $link = 'map.php?' . http_build_query([
                    'q' => $q,
                    'category' => $category_id ?: '',
                    'feature' => $feature_id ?: '',
                    'place' => $pid
                ]);
            ?>
                <a href="<?= h($link) ?>"
                   class="map-pin <?= $is_active ? 'selected' : '' ?>"
                   style="left: <?= (int)$p['map_x'] ?>%; top: <?= (int)$p['map_y'] ?>%;"
                   title="<?= h($p['name']) ?>">
                    <?= h($p['icon']) ?>
                </a>
            <?php endforeach; ?>

            <?php if ($selected_place): ?>
                <div class="selected-toast">
                    <?= h($selected_place['icon']) ?> <strong><?= h($selected_place['name']) ?></strong> таңдалды
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($selected_place):
        $sel_pid = (int)$selected_place['place_id'];
        $sel_feats = $place_features_map[$sel_pid] ?? [];
    ?>
        <section class="detail-panel">
            <div class="detail-top">
                <div>
                    <span class="section-kicker">ТАҢДАЛҒАН НЫСАН</span>
                    <h2><?= h($selected_place['icon']) ?> <?= h($selected_place['name']) ?></h2>
                    <p class="small-muted"><?= h($selected_place['address']) ?> · <?= h($selected_place['category_name']) ?> · 🕒 <?= h($selected_place['opening_hours']) ?> · 📞 <?= h($selected_place['phone']) ?></p>
                </div>

                <?php if (is_logged_in()): ?>
                    <form method="post" action="map.php">
                        <input type="hidden" name="action" value="toggle_favorite">
                        <input type="hidden" name="place_id" value="<?= $sel_pid ?>">
                        <button type="submit" class="btn <?= $is_fav ? 'btn-primary' : 'btn-outline' ?>">
                            <?= $is_fav ? '★ Таңдаулыларда' : '☆ Таңдаулыға қосу' ?>
                        </button>
                    </form>
                <?php else: ?>
                    <a href="login.php" class="btn btn-outline">Таңдаулыға қосу үшін кіріңіз</a>
                <?php endif; ?>
            </div>

            <div class="feature-badges">
                <?php foreach (['Пандус', 'Лифт', 'Арнайы тұрақ'] as $feat_name):
                    $has = in_array($feat_name, $sel_feats, true);
                ?>
                    <span class="feat-pill <?= $has ? 'yes' : 'no' ?>">
                        <?= $has ? '✓' : '✕' ?> <?= h($feat_name) ?>
                    </span>
                <?php endforeach; ?>
            </div>

            <p><?= h($selected_place['description']) ?></p>

            <hr class="divider">

            <div class="reviews-grid">
                <div>
                    <h3>Пікірлер (<?= count($place_reviews) ?>)</h3>
                    <?php if (empty($place_reviews)): ?>
                        <p class="small-muted">Бұл нысанға әлі пікір жазылмаған.</p>
                    <?php else: ?>
                        <?php foreach ($place_reviews as $rev): ?>
                            <div class="review-card">
                                <div class="review-head">
                                    <strong><?= h($rev['full_name']) ?></strong>
                                    <span><?= str_repeat('⭐', (int)$rev['rating']) ?> (<?= (int)$rev['rating'] ?>/5)</span>
                                </div>
                                <p><?= h($rev['comment']) ?></p>
                                <span class="small-muted"><?= h($rev['created_at']) ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div>
                    <h3>Пікір қалдыру</h3>
                    <?php if (!is_logged_in()): ?>
                        <div class="empty-box">
                            Пікір қалдыру үшін <a href="login.php">жүйеге кіріңіз</a> немесе <a href="register.php">тіркеліңіз</a>.
                        </div>
                    <?php else: ?>
                        <?php if (!empty($review_errors)): ?>
                            <div class="alert alert-error">
                                <?php foreach ($review_errors as $err): ?>
                                    <div>• <?= h($err) ?></div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($review_success): ?>
                            <div class="alert alert-success"><?= h($review_success) ?></div>
                        <?php endif; ?>

                        <form method="post" action="map.php" class="stack-form">
                            <input type="hidden" name="action" value="add_review">
                            <input type="hidden" name="place_id" value="<?= $sel_pid ?>">

                            <label>Автор: <strong><?= h(current_user()['full_name']) ?></strong></label>

                            <label>Қолжетімділік бағасы (1–5)</label>
                            <select name="rating" required>
                                <option value="5">5 — Өте ыңғайлы</option>
                                <option value="4">4 — Жақсы</option>
                                <option value="3">3 — Орташа</option>
                                <option value="2">2 — Қиындықтар бар</option>
                                <option value="1">1 — Қолжетімсіз</option>
                            </select>

                            <label>Пікір мәтіні</label>
                            <textarea name="comment" rows="3" required placeholder="Нысанның қолжетімділігі туралы пікіріңіз..."></textarea>

                            <button type="submit" class="btn btn-primary">Пікір жіберу</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
