<?php
$DB_HOST = '127.0.0.1';
$DB_NAME = 'accessmap_db';
$DB_USER = 'root';
$DB_PASS = ''; // XAMPP әдепкі құпиясөзі бос

$dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
} catch (PDOException $e) {
    die('
    <div style="font-family: Arial, sans-serif; max-width: 640px; margin: 40px auto; padding: 24px; border: 1px solid #f5c2c2; background: #fdecec; border-radius: 12px; color: #842029;">
        <h2 style="margin-top:0;">MySQL дерекқорына қосылу қатесі</h2>
        <p><strong>Қате мәтіні:</strong> ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p>
        <ol>
            <li>XAMPP Control Panel ішінен <strong>MySQL</strong> қызметін іске қосыңыз (Start).</li>
            <li><code>http://localhost/phpmyadmin</code> ашып, <code>sql/accessmap.sql</code> файлын импорттаңыз.</li>
        </ol>
    </div>');
}
?>
