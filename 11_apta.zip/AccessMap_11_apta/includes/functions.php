<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

function h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function redirect($page) {
    header('Location: ' . $page);
    exit;
}

function valid_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function is_logged_in() {
    return !empty($_SESSION['user']) && !empty($_SESSION['user']['user_id']);
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function is_admin() {
    return is_logged_in() && (($_SESSION['user']['role'] ?? 'user') === 'admin');
}

// Жабық беттерді қорғау функциясы
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['flash_error'] = 'Бұл бетке өту үшін алдымен жүйеге кіріңіз.';
        redirect('login.php');
    }
}

function current_page() {
    return basename($_SERVER['PHP_SELF']);
}
?>
