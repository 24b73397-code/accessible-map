</main>
<footer class="site-footer">
    <div class="container footer-wrap">
        <div>
            <strong>✦ AccessMap</strong> — Мүмкіндігі шектеулі адамдарға арналған қолжетімді нысандардың интерактивті картасы.
        </div>
        <div class="footer-note">
            11-апта: Дерекқор және аутентификация (PHP, MySQL, PDO, password_hash, Sessions)
        </div>
    </div>
</footer>
</body>
</html>
