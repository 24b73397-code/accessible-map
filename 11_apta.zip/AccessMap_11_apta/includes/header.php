<?php
require_once __DIR__ . '/functions.php';
$page = current_page();
$user = current_user();

$fav_count = 0;
if (is_logged_in()) {
    $stmtFav = $pdo->prepare("SELECT COUNT(*) FROM Favorites WHERE user_id = ?");
    $stmtFav->execute([$user['user_id']]);
    $fav_count = (int)$stmtFav->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AccessMap — Қолжетімді нысандардың интерактивті картасы</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a href="index.php" class="brand">
            <span class="brand-icon">✦</span>
            <span>AccessMap</span>
        </a>
        <nav class="main-nav">
            <a href="index.php" class="<?= $page === 'index.php' ? 'active' : '' ?>">Басты бет</a>
            <a href="map.php" class="<?= $page === 'map.php' ? 'active' : '' ?>">Нысандар картасы</a>
            <?php if (is_logged_in()): ?>
                <a href="add_place.php" class="<?= $page === 'add_place.php' ? 'active' : '' ?>">+ Нысан қосу</a>
                <a href="favorites.php" class="<?= $page === 'favorites.php' ? 'active' : '' ?>">Таңдаулылар (<?= $fav_count ?>)</a>
                <a href="profile.php" class="<?= $page === 'profile.php' ? 'active' : '' ?> user-pill">
                    👤 <?= h($user['full_name']) ?> <?= is_admin() ? '(Admin)' : '' ?>
                </a>
                <a href="logout.php" class="btn btn-outline btn-sm">Шығу</a>
            <?php else: ?>
                <a href="login.php" class="<?= $page === 'login.php' ? 'active' : '' ?>">Кіру</a>
                <a href="register.php" class="btn btn-primary btn-sm">Тіркелу</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="main-content">
