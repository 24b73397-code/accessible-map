<?php
require_once 'includes/functions.php';

if (is_logged_in()) {
    redirect('profile.php');
}

$errors = [];
$full_name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if ($full_name === '' || mb_strlen($full_name) < 2 || mb_strlen($full_name) > 150) {
        $errors[] = 'Аты-жөніңізді 2–150 таңба аралығында енгізіңіз.';
    }
    if (!valid_email($email)) {
        $errors[] = 'Электрондық пошта пішімі дұрыс емес.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Құпия сөз кемінде 8 таңбадан тұруы тиіс.';
    }
    if ($password !== $password_confirm) {
        $errors[] = 'Құпия сөздер сәйкес келмейді.';
    }

    if (empty($errors)) {
        // Email-дің дерекқорда бұрын тіркелген-тіркелмегенін тексеру
        $stmt = $pdo->prepare("SELECT user_id FROM Users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Бұл электрондық пошта жүйеде бұрын тіркелген.';
        } else {
            // Бірінші тіркелген пайдаланушыға admin рөлін беруге болады, қалғандарына user
            $total_users = (int)$pdo->query("SELECT COUNT(*) FROM Users")->fetchColumn();
            $role = ($total_users === 0) ? 'admin' : 'user';

            // Құпиясөзді password_hash() арқылы қауіпсіз сақтау
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            $insert = $pdo->prepare("INSERT INTO Users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)");
            $insert->execute([$full_name, $email, $password_hash, $role]);
            $new_user_id = (int)$pdo->lastInsertId();

            session_regenerate_id(true);
            $_SESSION['user'] = [
                'user_id'   => $new_user_id,
                'full_name' => $full_name,
                'email'     => $email,
                'role'      => $role
            ];

            redirect('profile.php');
        }
    }
}

include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card">
        <span class="section-kicker">ACCESSMAP АУТЕНТИФИКАЦИЯ</span>
        <h1>Аккаунт ашу</h1>
        <p class="small-muted">Деректер MySQL <code>Users</code> кестесіне, құпиясөз <code>password_hash()</code> арқылы сақталады.</p>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?>
                    <div>• <?= h($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="register.php" class="stack-form">
            <label for="full_name">Аты-жөні</label>
            <input id="full_name" type="text" name="full_name" required maxlength="150"
                   value="<?= h($full_name) ?>" placeholder="Аты-жөніңіз">

            <label for="email">Электрондық пошта</label>
            <input id="email" type="email" name="email" required
                   value="<?= h($email) ?>" placeholder="example@mail.com">

            <label for="password">Құпия сөз</label>
            <input id="password" type="password" name="password" required minlength="8"
                   placeholder="Кемінде 8 таңба">

            <label for="password_confirm">Құпия сөзді қайталау</label>
            <input id="password_confirm" type="password" name="password_confirm" required minlength="8"
                   placeholder="Құпия сөзді қайта енгізіңіз">

            <button type="submit" class="btn btn-primary btn-block">Тіркелу</button>
        </form>

        <p class="auth-switch">Аккаунтыңыз бар ма? <a href="login.php">Кіру</a></p>
        <p class="small-muted">Ескертпе: дерекқордағы ең алғашқы тіркелген пайдаланушыға автоматты түрде <code>admin</code> рөлі беріледі.</p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
