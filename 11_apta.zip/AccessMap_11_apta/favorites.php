<?php
require_once 'includes/functions.php';
require_login(); // Жабық бетті қорғау!

$user_id = (int)current_user()['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'remove_fav') {
    $remove_id = filter_var($_POST['place_id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
    if ($remove_id > 0) {
        $del = $pdo->prepare("DELETE FROM Favorites WHERE user_id = ? AND place_id = ?");
        $del->execute([$user_id, $remove_id]);
    }
}

$stmt = $pdo->prepare("SELECT p.*, c.category_name, f.saved_at
                       FROM Favorites f
                       INNER JOIN Places p ON f.place_id = p.place_id
                       LEFT JOIN Categories c ON p.category_id = c.category_id
                       WHERE f.user_id = ?
                       ORDER BY f.saved_at DESC");
$stmt->execute([$user_id]);
$fav_places = $stmt->fetchAll();

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">ЖАБЫҚ БЕТ · ЖЕКЕ ТІЗІМ</span>
        <h1>Таңдаулы нысандар</h1>
        <p class="small-muted">MySQL <code>Favorites</code> кестесінде сақталған жеке тізіміңіз.</p>
    </div>

    <?php if (empty($fav_places)): ?>
        <div class="empty-box">
            Таңдаулылар тізімі әзірге бос. <a href="map.php">Картадан нысан таңдаңыз →</a>
        </div>
    <?php else: ?>
        <div class="cards-3">
            <?php foreach ($fav_places as $p): ?>
                <div class="info-card">
                    <div class="icon-box"><?= h($p['icon']) ?></div>
                    <h3><?= h($p['name']) ?></h3>
                    <p class="small-muted"><?= h($p['category_name']) ?> · <?= h($p['address']) ?></p>
                    <p><?= h($p['description']) ?></p>
                    <div class="hero-actions" style="margin-top: 12px;">
                        <a href="map.php?place=<?= (int)$p['place_id'] ?>" class="btn btn-primary btn-sm">Картадан ашу</a>
                        <form method="post" action="favorites.php" style="display:inline;">
                            <input type="hidden" name="action" value="remove_fav">
                            <input type="hidden" name="place_id" value="<?= (int)$p['place_id'] ?>">
                            <button type="submit" class="btn btn-outline btn-sm">Жою</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
