<?php
require_once 'includes/functions.php';
include 'includes/header.php';

$places_count = (int)$pdo->query("SELECT COUNT(*) FROM Places")->fetchColumn();
$users_count  = (int)$pdo->query("SELECT COUNT(*) FROM Users")->fetchColumn();
?>
<div class="container">
    <section class="hero-grid">
        <div class="hero-text">
            <span class="pill-badge">♿ КЕДЕРГІСІЗ ОРТА — БӘРІМІЗГЕ ОРТАҚ</span>
            <h1>Қаладағы әр орын <span class="text-blue">қолжетімді</span> болсын</h1>
            <p class="lead">
                AccessMap — қоғамдық нысандардың пандус, лифт, арнайы тұрақ және басқа қолжетімділік мүмкіндіктерін MySQL дерекқоры арқылы алдын ала қарауға арналған веб-қосымша.
            </p>
            <div class="hero-actions">
                <a href="map.php" class="btn btn-primary">🗺️ Картаны ашу (<?= $places_count ?> нысан)</a>
                <?php if (!is_logged_in()): ?>
                    <a href="register.php" class="btn btn-outline">Аккаунт ашу</a>
                <?php else: ?>
                    <a href="profile.php" class="btn btn-outline">Жеке кабинет</a>
                <?php endif; ?>
            </div>
            <p class="muted-note">
                11-апта: MySQL (<code>accessmap_db</code>) дерекқоры, PDO қосылымы, <code>password_hash()</code> тіркелу және <code>session_start()</code> аутентификациясы қосылды. Тіркелген қолданушылар: <strong><?= $users_count ?></strong>.
            </p>
        </div>

        <div class="hero-card-visual">
            <div class="map-preview-card">
                <div class="floating-tag tag-top">✓ Пандус</div>
                <div class="floating-tag tag-right">♿ Арнайы тұрақ</div>
                <div class="floating-tag tag-bottom">🔒 PDO + MySQL</div>
                <div class="map-emoji">🗺️</div>
                <p class="small-muted">Дерекқорға қосылған интерактивті каталог</p>
            </div>
        </div>
    </section>

    <section class="section-block">
        <div class="section-center">
            <span class="section-kicker">11-АПТА ФУНКЦИОНАЛЫ</span>
            <h2>Аутентификация және дерекқор мүмкіндіктері</h2>
        </div>

        <div class="cards-3">
            <div class="info-card">
                <div class="icon-box">🗄️</div>
                <h3>MySQL және PDO</h3>
                <p>ER-диаграммаға сәйкес 8 кесте құрылып, дайындалған сұраныстар (Prepared Statements) арқылы қауіпсіз қосылым жасалды.</p>
            </div>
            <div class="info-card">
                <div class="icon-box">🔐</div>
                <h3>Тіркелу және password_hash()</h3>
                <p>Пайдаланушы құпиясөзі ашық күйде сақталмайды — <code>password_hash()</code> арқылы шифрланып, <code>password_verify()</code> арқылы тексеріледі.</p>
            </div>
            <div class="info-card">
                <div class="icon-box">🛡️</div>
                <h3>Сессия және жабық беттер</h3>
                <p><code>require_login()</code> функциясы арқылы жаңа нысан қосу, таңдаулылар және жеке профиль беттері бөгде кіруден қорғалған.</p>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>
