# AccessMap — 11-апта (Дерекқор және аутентификация: PHP, MySQL, PDO)

11-апта тапсырмасы бойынша AccessMap жобасына MySQL дерекқоры мен толық аутентификация жүйесі қосылды:
- **MySQL дерекқоры (`sql/accessmap.sql`)**: ER-диаграммаға сәйкес 8 кесте (`Users`, `Categories`, `AccessibilityFeatures`, `Places`, `PlaceFeatures`, `Favorites`, `Reviews`, `Routes`).
- **PDO қосылымы (`includes/db.php`)**: дайындалған сұраныстар (`prepare` / `execute`) арқылы SQL-инъекциядан қорғалған жұмыс.
- **Тіркелу (`register.php`)**: құпиясөздерді `password_hash($password, PASSWORD_DEFAULT)` арқылы шифрлап сақтау.
- **Кіру, сессиялар және шығу (`login.php`, `logout.php`, `includes/functions.php`)**: `password_verify()`, `session_start()`, `session_regenerate_id(true)` және `session_destroy()`.
- **Жабық беттерді қорғау (`require_login()`)**: `profile.php`, `add_place.php`, `favorites.php` беттері тек авторизацияланған пайдаланушыларға ашылады.

## Іске қосу нұсқаулығы
1. `AccessMap_11_apta` қалтасын `C:\xampp\htdocs\` ішіне көшіріңіз.
2. **XAMPP Control Panel** ашып, **Apache** және **MySQL** қызметтерін қосыңыз (`Start`).
3. Браузерде `http://localhost/phpmyadmin` ашып, **Импорт (Import)** бөлімі арқылы `AccessMap_11_apta/sql/accessmap.sql` файлын жүктеңіз (ол `accessmap_db` базасын және кестелерді автоматты түрде құрады).
4. Браузерде `http://localhost/AccessMap_11_apta/index.php` мекенжайын ашып, тіркелу (`register.php`), кіру (`login.php`) және шығу (`logout.php`) мүмкіндіктерін тексеріңіз.
