<?php
require_once 'includes/functions.php';
require_login(); // Жабық бетті қорғау!

$categories = $pdo->query("SELECT category_id, category_name FROM Categories ORDER BY category_id")->fetchAll();
$all_features = $pdo->query("SELECT feature_id, feature_name FROM AccessibilityFeatures ORDER BY feature_id")->fetchAll();

$errors = [];
$name = '';
$category_id = 1;
$address = '';
$phone = '';
$opening_hours = '09:00 – 18:00';
$description = '';
$selected_features = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = filter_var($_POST['category_id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $opening_hours = trim($_POST['opening_hours'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $selected_features = array_map('intval', $_POST['features'] ?? []);

    if ($name === '' || mb_strlen($name) > 200) {
        $errors[] = 'Нысан атауын 1–200 таңба аралығында енгізіңіз.';
    }
    if ($category_id <= 0) {
        $errors[] = 'Санатты таңдаңыз.';
    }
    if ($address === '' || mb_strlen($address) > 255) {
        $errors[] = 'Мекенжайды енгізіңіз.';
    }

    if (empty($errors)) {
        $icons = [1 => '🏥', 2 => '📚', 3 => '🛍️', 4 => '🎭'];
        $icon = $icons[$category_id] ?? '📍';

        $stmt = $pdo->prepare("INSERT INTO Places (name, category_id, address, phone, opening_hours, description, map_x, map_y, icon, created_by)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $name,
            $category_id,
            $address,
            $phone ?: '+7 (727) 000-00-00',
            $opening_hours ?: '09:00 – 18:00',
            $description ?: 'Пайдаланушы қосқан қолжетімділік нысаны.',
            rand(20, 80),
            rand(20, 80),
            $icon,
            current_user()['user_id']
        ]);
        $new_place_id = (int)$pdo->lastInsertId();

        if (!empty($selected_features)) {
            $stmtPF = $pdo->prepare("INSERT IGNORE INTO PlaceFeatures (place_id, feature_id, availability_status) VALUES (?, ?, 'available')");
            foreach ($selected_features as $fid) {
                $stmtPF->execute([$new_place_id, $fid]);
            }
        }

        redirect('map.php?place=' . $new_place_id);
    }
}

include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card" style="max-width: 560px;">
        <span class="section-kicker">ЖАБЫҚ БЕТ · ЖАҢА НЫСАН ҚОСУ</span>
        <h1>Қолжетімді нысанды тіркеу</h1>
        <p class="small-muted">Деректер MySQL <code>Places</code> және <code>PlaceFeatures</code> кестелеріне сақталады.</p>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?>
                    <div>• <?= h($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="add_place.php" class="stack-form">
            <label>Нысан атауы *</label>
            <input type="text" name="name" required maxlength="200" value="<?= h($name) ?>" placeholder="Мысалы: №5 Қалалық емхана">

            <label>Санаты *</label>
            <select name="category_id" required>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= (int)$cat['category_id'] ?>" <?= $category_id === (int)$cat['category_id'] ? 'selected' : '' ?>>
                        <?= h($cat['category_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Мекенжайы *</label>
            <input type="text" name="address" required maxlength="255" value="<?= h($address) ?>" placeholder="Мысалы: Абай даңғылы, 44">

            <label>Байланыс телефоны</label>
            <input type="text" name="phone" value="<?= h($phone) ?>" placeholder="+7 (727) 250-00-00">

            <label>Жұмыс уақыты</label>
            <input type="text" name="opening_hours" value="<?= h($opening_hours) ?>" placeholder="09:00 – 18:00">

            <label>Қолжетімділік ерекшеліктері</label>
            <div class="checkbox-row">
                <?php foreach ($all_features as $feat): ?>
                    <label class="check-item">
                        <input type="checkbox" name="features[]" value="<?= (int)$feat['feature_id'] ?>"
                            <?= in_array((int)$feat['feature_id'], $selected_features, true) ? 'checked' : '' ?>>
                        <span><?= h($feat['feature_name']) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>

            <label>Сипаттама</label>
            <textarea name="description" rows="3" placeholder="Кіреберіс пен жабдықталуы туралы қысқаша ақпарат..."><?= h($description) ?></textarea>

            <button type="submit" class="btn btn-primary btn-block">Дерекқорға сақтау</button>
        </form>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
