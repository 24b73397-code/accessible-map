<?php
require_once 'includes/functions.php';

$q = trim($_GET['q'] ?? '');
$cat_id = filter_var($_GET['category'] ?? 0, FILTER_VALIDATE_INT);
$feat_id = filter_var($_GET['feature'] ?? 0, FILTER_VALIDATE_INT);
$selected_id = filter_var($_GET['place'] ?? 0, FILTER_VALIDATE_INT);

$review_errors = [];
$review_success = '';

if (!empty($_SESSION['flash_error'])) {
    $review_errors[] = $_SESSION['flash_error'];
    unset($_SESSION['flash_error']);
}

// POST: Таңдаулылар немесе пікір қалдыру (Create Review)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_login();
    $user_id = (int)current_user()['user_id'];
    $action = $_POST['action'] ?? '';
    $target_place = filter_var($_POST['place_id'] ?? 0, FILTER_VALIDATE_INT);
    $selected_id = $target_place;

    if ($action === 'toggle_favorite' && $target_place > 0) {
        $chk = $pdo->prepare("SELECT favorite_id FROM Favorites WHERE user_id = ? AND place_id = ?");
        $chk->execute([$user_id, $target_place]);
        if ($chk->fetch()) {
            $pdo->prepare("DELETE FROM Favorites WHERE user_id = ? AND place_id = ?")->execute([$user_id, $target_place]);
        } else {
            $pdo->prepare("INSERT INTO Favorites (user_id, place_id) VALUES (?, ?)")->execute([$user_id, $target_place]);
        }
    }

    if ($action === 'add_review' && $target_place > 0) {
        $rating = filter_var($_POST['rating'] ?? 5, FILTER_VALIDATE_INT);
        $comment = trim($_POST['comment'] ?? '');
        if (mb_strlen($comment) < 3) { $review_errors[] = 'Пікір тым қысқа.'; }
        if (empty($review_errors)) {
            $insRev = $pdo->prepare("INSERT INTO Reviews (user_id, place_id, rating, comment) VALUES (?, ?, ?, ?)");
            $insRev->execute([$user_id, $target_place, $rating, $comment]);
            $review_success = 'Пікіріңіз сәтті сақталды!';
        }
    }
}

$categories = $pdo->query("SELECT * FROM Categories")->fetchAll();
$all_features = $pdo->query("SELECT * FROM AccessibilityFeatures")->fetchAll();

// READ сұранысы (Prepared Statements)
$sql = "SELECT DISTINCT p.*, c.category_name, u.full_name as author_name FROM Places p LEFT JOIN Categories c ON p.category_id = c.category_id LEFT JOIN Users u ON p.created_by = u.user_id";
$params = [];
$where = [];

if ($feat_id > 0) {
    $sql .= " INNER JOIN PlaceFeatures pf ON p.place_id = pf.place_id AND pf.feature_id = ? AND pf.availability_status = 'available'";
    $params[] = $feat_id;
}
if ($q !== '') {
    $where[] = "(p.name LIKE ? OR p.address LIKE ?)";
    $like = '%' . $q . '%';
    $params[] = $like;
    $params[] = $like;
}
if ($cat_id > 0) {
    $where[] = "p.category_id = ?";
    $params[] = $cat_id;
}
if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY p.place_id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$places = $stmt->fetchAll();

// Ерекшеліктер картасы
$feat_map = [];
$frs = $pdo->query("SELECT pf.place_id, af.feature_name FROM PlaceFeatures pf INNER JOIN AccessibilityFeatures af ON pf.feature_id = af.feature_id WHERE pf.availability_status = 'available'")->fetchAll();
foreach ($frs as $f) {
    $feat_map[(int)$f['place_id']][] = $f['feature_name'];
}

$selected_place = null;
foreach ($places as $p) {
    if ((int)$p['place_id'] === $selected_id) { $selected_place = $p; break; }
}
if (!$selected_place && !empty($places)) { $selected_place = $places[0]; }

$place_reviews = [];
$is_fav = false;
if ($selected_place) {
    $sel_id = (int)$selected_place['place_id'];
    $revs = $pdo->prepare("SELECT r.*, u.full_name FROM Reviews r INNER JOIN Users u ON r.user_id = u.user_id WHERE r.place_id = ? ORDER BY r.review_id DESC");
    $revs->execute([$sel_id]);
    $place_reviews = $revs->fetchAll();

    if (is_logged_in()) {
        $chkFav = $pdo->prepare("SELECT 1 FROM Favorites WHERE user_id = ? AND place_id = ?");
        $chkFav->execute([current_user()['user_id'], $sel_id]);
        $is_fav = (bool)$chkFav->fetchColumn();
    }
}

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">READ & CRUD CATALOG</span>
        <h1>Қолжетімді нысандар каталогы</h1>
        <p class="small-muted">Барлық нысандар базадан оқылады (Read), ізделеді және толық басқарылады.</p>
    </div>

    <form method="get" class="filter-panel">
        <div class="filter-field">
            <label>Іздеу</label>
            <input type="text" name="q" value="<?= h($q) ?>" placeholder="Атауы немесе мекенжайы...">
        </div>
        <div class="filter-field">
            <label>Санат</label>
            <select name="category">
                <option value="">Барлық санаттар</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= (int)$c['category_id'] ?>" <?= $cat_id === (int)$c['category_id'] ? 'selected' : '' ?>><?= h($c['category_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-field">
            <label>Қолжетімділік</label>
            <select name="feature">
                <option value="">Барлық мүмкіндіктер</option>
                <?php foreach ($all_features as $f): ?>
                    <option value="<?= (int)$f['feature_id'] ?>" <?= $feat_id === (int)$f['feature_id'] ? 'selected' : '' ?>><?= h($f['feature_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-actions">
            <button type="submit" class="btn btn-primary">Іздеу</button>
            <a href="map.php" class="btn btn-outline">Тазарту</a>
        </div>
    </form>

    <div class="map-layout">
        <div class="places-column">
            <div class="list-header">
                <h3>Нысандар тізімі</h3>
                <span class="small-muted"><?= count($places) ?> нысан</span>
            </div>
            <?php if (empty($places)): ?>
                <div class="empty-box">Нысан табылмады.</div>
            <?php else: ?>
                <?php foreach ($places as $p):
                    $pid = (int)$p['place_id'];
                    $active = $selected_place && (int)$selected_place['place_id'] === $pid;
                    $link = 'map.php?' . http_build_query(['q' => $q, 'category' => $cat_id, 'feature' => $feat_id, 'place' => $pid]);
                ?>
                    <a href="<?= h($link) ?>" class="place-item <?= $active ? 'active' : '' ?>">
                        <div class="place-icon"><?= h($p['icon']) ?></div>
                        <div class="place-meta">
                            <strong><?= h($p['name']) ?></strong>
                            <span class="small-muted"><?= h($p['category_name']) ?> · <?= h($p['address']) ?></span>
                        </div>
                        <span class="arrow">→</span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="map-board">
            <div class="board-label">ІЗДЕУ ЖӘНЕ КАРТА МАКЕТІ</div>
            <div class="road road-1"></div>
            <div class="road road-2"></div>
            <?php foreach ($places as $p):
                $pid = (int)$p['place_id'];
                $active = $selected_place && (int)$selected_place['place_id'] === $pid;
                $link = 'map.php?' . http_build_query(['q' => $q, 'category' => $cat_id, 'feature' => $feat_id, 'place' => $pid]);
            ?>
                <a href="<?= h($link) ?>" class="map-pin <?= $active ? 'selected' : '' ?>" style="left:<?= (int)$p['map_x'] ?>%; top:<?= (int)$p['map_y'] ?>%;" title="<?= h($p['name']) ?>">
                    <?= h($p['icon']) ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if ($selected_place):
        $sel_id = (int)$selected_place['place_id'];
        $p_feats = $feat_map[$sel_id] ?? [];
        $can_edit = is_logged_in() && (is_admin() || (int)$selected_place['created_by'] === (int)current_user()['user_id']);
    ?>
        <section class="detail-panel">
            <div class="detail-top">
                <div>
                    <span class="section-kicker">ТАҢДАЛҒАН НЫСАН (CRUD DETAILS)</span>
                    <h2><?= h($selected_place['icon']) ?> <?= h($selected_place['name']) ?></h2>
                    <p class="small-muted"><?= h($selected_place['address']) ?> · 🕒 <?= h($selected_place['opening_hours']) ?> · 📞 <?= h($selected_place['phone']) ?></p>
                </div>
                <div class="hero-actions">
                    <?php if (is_logged_in()): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="action" value="toggle_favorite">
                            <input type="hidden" name="place_id" value="<?= $sel_id ?>">
                            <button type="submit" class="btn <?= $is_fav ? 'btn-primary' : 'btn-outline' ?>">
                                <?= $is_fav ? '★ Таңдаулыда' : '☆ Таңдаулыға қосу' ?>
                            </button>
                        </form>
                    <?php endif; ?>

                    <?php if ($can_edit): ?>
                        <a href="edit_place.php?id=<?= $sel_id ?>" class="btn btn-outline" style="background:#fff3cd;color:#856404;border-color:#ffeeba;">✏️ Өңдеу (Update)</a>
                        <a href="delete_place.php?id=<?= $sel_id ?>" class="btn btn-outline" style="background:#fdecec;color:#a61b1b;border-color:#f5c2c2;" onclick="return confirm('Бұл нысанды жоюды растайсыз ба?');">🗑️ Жою (Delete)</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="feature-badges">
                <?php foreach (['Пандус', 'Лифт', 'Арнайы тұрақ'] as $fn): $has = in_array($fn, $p_feats); ?>
                    <span class="feat-pill <?= $has ? 'yes' : 'no' ?>"><?= $has ? '✓' : '✕' ?> <?= h($fn) ?></span>
                <?php endforeach; ?>
            </div>
            <p><?= h($selected_place['description']) ?></p>
            <p class="small-muted">Қосқан автор: <strong><?= h($selected_place['author_name'] ?? 'Әкімші') ?></strong></p>

            <hr class="divider">

            <div class="reviews-grid">
                <div>
                    <h3>Пікірлер (<?= count($place_reviews) ?>)</h3>
                    <?php if (empty($place_reviews)): ?>
                        <p class="small-muted">Әлі пікір жоқ.</p>
                    <?php else: ?>
                        <?php foreach ($place_reviews as $r):
                            $can_del_rev = is_logged_in() && (is_admin() || (int)$r['user_id'] === (int)current_user()['user_id']);
                        ?>
                            <div class="review-card">
                                <div class="review-head">
                                    <strong><?= h($r['full_name']) ?></strong>
                                    <span><?= str_repeat('⭐', (int)$r['rating']) ?></span>
                                </div>
                                <p><?= h($r['comment']) ?></p>
                                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:6px;">
                                    <span class="small-muted"><?= h($r['created_at']) ?></span>
                                    <?php if ($can_del_rev): ?>
                                        <a href="delete_review.php?id=<?= (int)$r['review_id'] ?>" style="color:#a61b1b;font-size:12px;" onclick="return confirm('Пікірді жоюды растайсыз ба?');">Жою</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div>
                    <h3>Пікір қалдыру (Create Review)</h3>
                    <?php if (!is_logged_in()): ?>
                        <div class="empty-box">Пікір жазу үшін <a href="login.php">кіріңіз</a>.</div>
                    <?php else: ?>
                        <?php if (!empty($review_errors)): ?>
                            <div class="alert alert-error"><?= h($review_errors[0]) ?></div>
                        <?php endif; ?>
                        <?php if ($review_success): ?>
                            <div class="alert alert-success"><?= h($review_success) ?></div>
                        <?php endif; ?>
                        <form method="post" class="stack-form">
                            <input type="hidden" name="action" value="add_review">
                            <input type="hidden" name="place_id" value="<?= $sel_id ?>">
                            <label>Баға</label>
                            <select name="rating">
                                <option value="5">5 — Өте жақсы</option>
                                <option value="4">4 — Жақсы</option>
                                <option value="3">3 — Орташа</option>
                                <option value="2">2 — Нашар</option>
                                <option value="1">1 — Қолжетімсіз</option>
                            </select>
                            <label>Пікір мәтіні</label>
                            <textarea name="comment" rows="3" required placeholder="Пікіріңізді жазыңыз..."></textarea>
                            <button type="submit" class="btn btn-primary">Пікір жіберу</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>