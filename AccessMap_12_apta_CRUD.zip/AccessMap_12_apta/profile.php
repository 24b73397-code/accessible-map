<?php
require_once 'includes/functions.php';
require_login();
$user = current_user();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM Places WHERE created_by = ?");
$stmt->execute([$user['user_id']]);
$my_places = (int)$stmt->fetchColumn();

$stmt2 = $pdo->prepare("SELECT COUNT(*) FROM Reviews WHERE user_id = ?");
$stmt2->execute([$user['user_id']]);
$my_reviews = (int)$stmt2->fetchColumn();

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">ЖЕКЕ КАБИНЕТ</span>
        <h1>Қош келдіңіз, <?= h($user['full_name']) ?>!</h1>
        <p class="small-muted">Бұл бет тек авторизацияланған пайдаланушыларға қолжетімді.</p>
    </div>
    <div class="cards-3">
        <div class="info-card">
            <div class="icon-box">👤</div>
            <h3>Профиль деректері</h3>
            <p><strong>Email:</strong> <?= h($user['email']) ?></p>
            <p><strong>Рөлі:</strong> <span class="pill-badge"><?= h($user['role']) ?></span></p>
        </div>
        <div class="info-card">
            <div class="icon-box">📊</div>
            <h3>Сіздің белсенділігіңіз</h3>
            <p><strong>Қосқан нысандарыңыз (Create):</strong> <?= $my_places ?></p>
            <p><strong>Жазған пікірлеріңіз:</strong> <?= $my_reviews ?></p>
        </div>
        <div class="info-card">
            <div class="icon-box">⚡</div>
            <h3>Жылдам әрекеттер</h3>
            <div class="stack-form">
                <a href="add_place.php" class="btn btn-primary">+ Жаңа нысан қосу (Create)</a>
                <a href="map.php" class="btn btn-outline">🗺️ Нысандар каталогына өту</a>
                <a href="logout.php" class="btn btn-outline" style="color:#a61b1b;border-color:#f5c2c2;">Жүйеден шығу</a>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>