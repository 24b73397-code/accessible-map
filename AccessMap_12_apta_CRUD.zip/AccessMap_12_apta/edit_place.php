<?php
require_once 'includes/functions.php';
require_login();

$place_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
if (!$place_id) { redirect('map.php'); }

$stmt = $pdo->prepare("SELECT * FROM Places WHERE place_id = ?");
$stmt->execute([$place_id]);
$place = $stmt->fetch();

if (!$place) { redirect('map.php'); }

// Рұқсатты тексеру: Тек нысанды қосқан автор немесе admin ғана өңдей алады
$user = current_user();
if (!is_admin() && (int)$place['created_by'] !== (int)$user['user_id']) {
    $_SESSION['flash_error'] = 'Бұл нысанды өңдеуге құқығыңыз жоқ.';
    redirect('map.php?place=' . $place_id);
}

$categories = $pdo->query("SELECT * FROM Categories")->fetchAll();
$all_features = $pdo->query("SELECT * FROM AccessibilityFeatures")->fetchAll();

$stmt_pf = $pdo->prepare("SELECT feature_id FROM PlaceFeatures WHERE place_id = ? AND availability_status = 'available'");
$stmt_pf->execute([$place_id]);
$current_features = array_column($stmt_pf->fetchAll(), 'feature_id');

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 1);
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $opening_hours = trim($_POST['opening_hours'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $selected_features = array_map('intval', $_POST['features'] ?? []);

    if ($name === '') { $errors[] = 'Нысан атауы міндетті.'; }
    if ($address === '') { $errors[] = 'Мекенжай міндетті.'; }

    if (empty($errors)) {
        $icons = [1 => '🏥', 2 => '📚', 3 => '🛍️', 4 => '🎭'];
        $icon = $icons[$category_id] ?? '📍';

        // UPDATE сұранысы (Prepared Statement)
        $upd = $pdo->prepare("UPDATE Places SET name = ?, category_id = ?, address = ?, phone = ?, opening_hours = ?, description = ?, icon = ? WHERE place_id = ?");
        $upd->execute([$name, $category_id, $address, $phone, $opening_hours, $description, $icon, $place_id]);

        // Байланыстарды жаңарту (Delete + Insert)
        $pdo->prepare("DELETE FROM PlaceFeatures WHERE place_id = ?")->execute([$place_id]);
        if (!empty($selected_features)) {
            $insF = $pdo->prepare("INSERT IGNORE INTO PlaceFeatures (place_id, feature_id, availability_status) VALUES (?, ?, 'available')");
            foreach ($selected_features as $fid) {
                $insF->execute([$place_id, $fid]);
            }
        }
        redirect('map.php?place=' . $place_id);
    }
}
include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card" style="max-width:560px;">
        <span class="section-kicker">UPDATE OPERATION</span>
        <h1>Нысанды өңдеу: <?= h($place['name']) ?></h1>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?><div>• <?= h($e) ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="post" class="stack-form">
            <label>Нысан атауы *</label>
            <input type="text" name="name" required value="<?= h($place['name']) ?>">
            <label>Санаты *</label>
            <select name="category_id">
                <?php foreach ($categories as $c): ?>
                    <option value="<?= (int)$c['category_id'] ?>" <?= (int)$place['category_id'] === (int)$c['category_id'] ? 'selected' : '' ?>><?= h($c['category_name']) ?></option>
                <?php endforeach; ?>
            </select>
            <label>Мекенжайы *</label>
            <input type="text" name="address" required value="<?= h($place['address']) ?>">
            <label>Телефон</label>
            <input type="text" name="phone" value="<?= h($place['phone']) ?>">
            <label>Жұмыс уақыты</label>
            <input type="text" name="opening_hours" value="<?= h($place['opening_hours']) ?>">
            <label>Қолжетімділік ерекшеліктері</label>
            <div class="checkbox-row">
                <?php foreach ($all_features as $f): ?>
                    <label class="check-item">
                        <input type="checkbox" name="features[]" value="<?= (int)$f['feature_id'] ?>" <?= in_array((int)$f['feature_id'], $current_features) ? 'checked' : '' ?>>
                        <span><?= h($f['feature_name']) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <label>Сипаттама</label>
            <textarea name="description" rows="3"><?= h($place['description']) ?></textarea>
            <button type="submit" class="btn btn-primary btn-block">Өзгерістерді сақтау (Update)</button>
        </form>
        <p style="text-align:center;margin-top:12px;"><a href="map.php?place=<?= $place_id ?>">Қайту</a></p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>