# AccessMap — 12-апта (CRUD операциялары және Prepared Statements)

12-апта тапсырмасы бойынша AccessMap жобасына толық **CRUD** (Create, Read, Update, Delete) операциялары енгізілді:
- **Create**: `add_place.php` арқылы жаңа қолжетімді нысан тіркеу.
- **Read**: `map.php` арқылы MySQL деректерін оқу, іздеу және сүзгілеу.
- **Update**: `edit_place.php` арқылы нысан мәліметтерін өзгерту (тек автор немесе admin).
- **Delete**: `delete_place.php` және `delete_review.php` арқылы нысанды немесе пікірді жою.
- **Prepared Statements**: Барлық сұраныстар SQL-инъекциялардан қорғалған.

## Іске қосу нұсқаулығы
1. `AccessMap_12_apta` қалтасын `C:\xampp\htdocs\` ішіне көшіріңіз.
2. XAMPP Control Panel арқылы **Apache** мен **MySQL** қызметтерін қосыңыз.
3. `http://localhost/phpmyadmin` арқылы `sql/accessmap.sql` файлын импорттаңыз.
4. `C:\xampp\php\php.exe -S localhost:8080` арқылы іске қосып, `http://localhost:8080/index.php` мекенжайына кіріңіз.
