CREATE DATABASE IF NOT EXISTS accessmap_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE accessmap_db;

CREATE TABLE IF NOT EXISTS Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description TEXT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS AccessibilityFeatures (
    feature_id INT AUTO_INCREMENT PRIMARY KEY,
    feature_name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(100)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Places (
    place_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category_id INT,
    address VARCHAR(255) NOT NULL,
    latitude DECIMAL(10,7) DEFAULT NULL,
    longitude DECIMAL(10,7) DEFAULT NULL,
    phone VARCHAR(30),
    opening_hours VARCHAR(255),
    description TEXT,
    map_x INT DEFAULT 50,
    map_y INT DEFAULT 50,
    icon VARCHAR(20) DEFAULT '📍',
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES Categories(category_id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES Users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS PlaceFeatures (
    place_id INT NOT NULL,
    feature_id INT NOT NULL,
    availability_status ENUM('available', 'unavailable', 'unverified') DEFAULT 'available',
    notes TEXT,
    PRIMARY KEY (place_id, feature_id),
    FOREIGN KEY (place_id) REFERENCES Places(place_id) ON DELETE CASCADE,
    FOREIGN KEY (feature_id) REFERENCES AccessibilityFeatures(feature_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Favorites (
    favorite_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    place_id INT NOT NULL,
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_place (user_id, place_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (place_id) REFERENCES Places(place_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    place_id INT NOT NULL,
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (place_id) REFERENCES Places(place_id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO Categories (category_id, category_name, description) VALUES
(1, 'Медицина', 'Емханалар, ауруханалар, дәріханалар'),
(2, 'Білім беру', 'Кітапханалар, оқу орталықтары, университеттер'),
(3, 'Сауда', 'Сауда орталықтары мен дүкендер'),
(4, 'Мәдениет', 'Мәдениет үйлері, театрлар, музейлер')
ON DUPLICATE KEY UPDATE category_name = VALUES(category_name);

INSERT INTO AccessibilityFeatures (feature_id, feature_name, description, icon) VALUES
(1, 'Пандус', 'Кіреберістегі нормативтік көлбеу пандус', '♿'),
(2, 'Лифт', 'Қабаттар арасындағы кең жолаушылар лифті', '🛗'),
(3, 'Арнайы тұрақ', 'Мүгедектігі бар жандарға арналған көлік тұрағы', '🅿️')
ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);

INSERT INTO Places (place_id, name, category_id, address, latitude, longitude, phone, opening_hours, description, map_x, map_y, icon) VALUES
(1, 'Үлгі емхана', 1, 'Демо аймақ, 1-нысан', 43.2389490, 76.8897090, '+7 (727) 250-10-01', '08:00 – 20:00', 'Кіреберісте нормативтік көлбеу пандус, кең лифт және мүгедектігі бар жандарға арналған тұрақ орны бар.', 24, 28, '🏥'),
(2, 'Үлгі кітапхана', 2, 'Демо аймақ, 2-нысан', 43.2412000, 76.8951000, '+7 (727) 250-20-02', '09:00 – 19:00', 'Оқу залына кіретін пандус бар. Екінші қабатқа көтерілетін лифт әзірге жоқ.', 68, 24, '📚'),
(3, 'Үлгі дәріхана', 1, 'Демо аймақ, 3-нысан', 43.2356000, 76.8912000, '+7 (727) 250-30-03', 'Тәулік бойы', 'Төмен табалдырықты кіреберіс, пандус және жақын орналасқан арнайы тұрақ қарастырылған.', 45, 52, '💊')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT IGNORE INTO PlaceFeatures (place_id, feature_id, availability_status) VALUES
(1, 1, 'available'), (1, 2, 'available'), (1, 3, 'available'),
(2, 1, 'available'),
(3, 1, 'available'), (3, 3, 'available');
