</main>
<footer class="site-footer">
    <div class="container footer-wrap">
        <div><strong>✦ AccessMap</strong> — Мүмкіндігі шектеулі жандарға арналған қолжетімді нысандар каталоғы.</div>
        <div class="footer-note">12-апта: Толық CRUD операциялары (Create, Read, Update, Delete) + Prepared Statements</div>
    </div>
</footer>
</body>
</html>