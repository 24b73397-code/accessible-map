<?php
require_once 'includes/functions.php';
include 'includes/header.php';

$places_count = (int)$pdo->query("SELECT COUNT(*) FROM Places")->fetchColumn();
$users_count  = (int)$pdo->query("SELECT COUNT(*) FROM Users")->fetchColumn();
$reviews_count = (int)$pdo->query("SELECT COUNT(*) FROM Reviews")->fetchColumn();
?>
<div class="container">
    <section class="hero-grid">
        <div class="hero-text">
            <span class="pill-badge">⚙️ 12-АПТА · CRUD ОПЕРАЦИЯЛАРЫ</span>
            <h1>Дерекқормен толық жұмыс және <span class="text-blue">CRUD</span> басқару</h1>
            <p class="lead">
                AccessMap жобасының 12-аптасында нысандарды қосу (Create), көрсету (Read), түзету (Update) және өшіру (Delete) функциялары толық іске асырылды. Барлық SQL сұраныстары *Prepared Statements* арқылы қорғалған.
            </p>
            <div class="hero-actions">
                <a href="map.php" class="btn btn-primary">🗺️ Нысандар каталогына өту (<?= $places_count ?> нысан)</a>
                <?php if (is_logged_in()): ?>
                    <a href="add_place.php" class="btn btn-outline">+ Жаңа нысан қосу</a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-outline">Аккаунт ашу</a>
                <?php endif; ?>
            </div>
            <p class="muted-note">Жүйедегі тіркелген қолданушылар: <strong><?= $users_count ?></strong>, жазылған пікірлер: <strong><?= $reviews_count ?></strong>.</p>
        </div>
        <div class="hero-card-visual">
            <div class="map-preview-card">
                <div class="floating-tag tag-top">➕ Create Place</div>
                <div class="floating-tag tag-right">✏️ Update / Delete</div>
                <div class="floating-tag tag-bottom">🛡️ Prepared Statements</div>
                <div class="map-emoji">🛠️</div>
                <p class="small-muted">Толық CRUD архитектурасы</p>
            </div>
        </div>
    </section>

    <section class="section-block">
        <div class="section-center">
            <span class="section-kicker">12-АПТА МҮМКІНДІКТЕРІ</span>
            <h2>CRUD операциялары және қауіпсіздік</h2>
        </div>
        <div class="cards-3">
            <div class="info-card">
                <div class="icon-box">➕</div>
                <h3>1. Create & Read</h3>
                <p>Пайдаланушылар жаңа нысан қосып (<code>add_place.php</code>) және оны карта мен тізім арқылы көре алады (<code>map.php</code>).</p>
            </div>
            <div class="info-card">
                <div class="icon-box">✏️</div>
                <h3>2. Update & Delete</h3>
                <p>Нысан авторы немесе әкімші нысан мәліметтерін өңдеп (<code>edit_place.php</code>) немесе жүйеден толық жоя алады (<code>delete_place.php</code>).</p>
            </div>
            <div class="info-card">
                <div class="icon-box">🛡️</div>
                <h3>3. Prepared Statements</h3>
                <p>Барлық SQL сұраныстарында <code>PDO prepare()</code> және <code>execute()</code> қолданылып, SQL-инъекциялардан 100% қорғалған.</p>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>