<?php
require_once 'includes/functions.php';

if (is_logged_in()) {
    redirect('map.php');
}

$errors = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!valid_email($email)) {
        $errors[] = 'Жарамды электрондық пошта енгізіңіз.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Құпия сөз кемінде 8 таңбадан тұруы тиіс.';
    }

    if (empty($errors)) {
        $name_from_email = explode('@', $email)[0];
        $_SESSION['demo_user'] = [
            'name' => $name_from_email,
            'email' => $email,
            'role' => 'user'
        ];
        redirect('map.php');
    }
}

include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card">
        <span class="section-kicker">ҚОШ КЕЛДІҢІЗ!</span>
        <h1>Жүйеге кіру</h1>
        <p class="small-muted">AccessMap платформасына кіру формасы (<code>$_POST</code>).</p>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?>
                    <div>• <?= h($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="login.php" class="stack-form">
            <label for="email">Электрондық пошта</label>
            <input id="email" type="email" name="email" required
                   value="<?= h($email) ?>" placeholder="example@mail.com">

            <label for="password">Құпия сөз</label>
            <input id="password" type="password" name="password" required minlength="8"
                   placeholder="Құпия сөз">

            <button type="submit" class="btn btn-primary btn-block">Кіруді тексеру</button>
        </form>

        <p class="auth-switch">Аккаунтыңыз жоқ па? <a href="register.php">Тіркелу</a></p>
        <p class="small-muted">Нақты дерекқор авторизациясы 11-аптада MySQL арқылы іске асады.</p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
