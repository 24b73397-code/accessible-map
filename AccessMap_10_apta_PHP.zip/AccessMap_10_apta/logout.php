<?php
require_once 'includes/functions.php';
unset($_SESSION['demo_user']);
redirect('index.php');
?>
