<?php
require_once 'includes/functions.php';

// $_GET арқылы іздеу және сүзгілеу параметрлерін қабылдау
$q = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');
$feature = trim($_GET['feature'] ?? '');
$selected_id = trim($_GET['place'] ?? '');

$review_errors = [];
$review_success = '';

// $_POST арқылы пікір қосу немесе таңдаулыларға сақтау
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $target_place_id = trim($_POST['place_id'] ?? '');

    if ($action === 'toggle_favorite' && $target_place_id !== '') {
        if (in_array($target_place_id, $_SESSION['favorites'], true)) {
            $_SESSION['favorites'] = array_values(array_diff($_SESSION['favorites'], [$target_place_id]));
        } else {
            $_SESSION['favorites'][] = $target_place_id;
        }
        $selected_id = $target_place_id;
    }

    if ($action === 'add_review') {
        $author = trim($_POST['author'] ?? '');
        $rating = filter_var($_POST['rating'] ?? null, FILTER_VALIDATE_INT);
        $comment = trim($_POST['comment'] ?? '');
        $selected_id = $target_place_id;

        if ($author === '' || mb_strlen($author) > 100) {
            $review_errors[] = 'Аты-жөніңізді 1–100 таңба аралығында енгізіңіз.';
        }
        if (!$rating || $rating < 1 || $rating > 5) {
            $review_errors[] = 'Баға 1 мен 5 аралығында болуы тиіс.';
        }
        if ($comment === '' || mb_strlen($comment) < 5) {
            $review_errors[] = 'Пікір мәтіні кемінде 5 таңбадан тұруы тиіс.';
        }

        if (empty($review_errors)) {
            $_SESSION['reviews'][] = [
                'place_id' => $target_place_id,
                'author' => $author,
                'rating' => $rating,
                'comment' => $comment,
                'created_at' => date('Y-m-d')
            ];
            $review_success = 'Пікіріңіз серверде тексеріліп, сәтті қосылды!';
        }
    }
}

// Нысандарды сүзгілеу
$filtered_places = [];
foreach ($_SESSION['places'] as $p) {
    if ($q !== '' && mb_stripos($p['name'] . ' ' . $p['address'] . ' ' . $p['category'], $q) === false) {
        continue;
    }
    if ($category !== '' && $p['category'] !== $category) {
        continue;
    }
    if ($feature !== '' && !in_array($feature, $p['features'], true)) {
        continue;
    }
    $filtered_places[] = $p;
}

// Таңдалған нысанды анықтау
$selected_place = null;
foreach ($filtered_places as $p) {
    if ($p['id'] === $selected_id) {
        $selected_place = $p;
        break;
    }
}
if (!$selected_place && !empty($filtered_places)) {
    $selected_place = $filtered_places[0];
}

// Таңдалған нысанның пікірлері
$place_reviews = [];
if ($selected_place) {
    foreach ($_SESSION['reviews'] as $rev) {
        if ($rev['place_id'] === $selected_place['id']) {
            $place_reviews[] = $rev;
        }
    }
}

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">КАРТА ЖӘНЕ КАТАЛОГ</span>
        <h1>Қолжетімді нысандарды табыңыз</h1>
        <p class="muted-note">
            Іздеу мен сүзгілер серверде <code>$_GET</code> параметрі арқылы өңделеді. Карта макетінен немесе тізімнен нысанды таңдаңыз.
        </p>
    </div>

    <!-- GET сүзгі формасы -->
    <form method="get" action="map.php" class="filter-panel">
        <div class="filter-field">
            <label for="q">Атауы бойынша іздеу</label>
            <input id="q" type="text" name="q" value="<?= h($q) ?>" placeholder="Емхана, кітапхана...">
        </div>
        <div class="filter-field">
            <label for="category">Санат</label>
            <select id="category" name="category">
                <option value="">Барлық санаттар</option>
                <?php foreach (['Медицина', 'Білім беру', 'Сауда', 'Мәдениет'] as $cat): ?>
                    <option value="<?= h($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= h($cat) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-field">
            <label for="feature">Қолжетімділік</label>
            <select id="feature" name="feature">
                <option value="">Барлық нысандар</option>
                <?php foreach (['Пандус', 'Лифт', 'Арнайы тұрақ'] as $feat): ?>
                    <option value="<?= h($feat) ?>" <?= $feature === $feat ? 'selected' : '' ?>><?= h($feat) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-actions">
            <button type="submit" class="btn btn-primary">Іздеу</button>
            <a href="map.php" class="btn btn-outline">Тазарту</a>
        </div>
    </form>

    <div class="map-layout">
        <!-- Сол жақ: Нысандар тізімі -->
        <div class="places-column">
            <div class="list-header">
                <h3>Нысандар</h3>
                <span class="small-muted"><?= count($filtered_places) ?> нысан</span>
            </div>

            <?php if (empty($filtered_places)): ?>
                <div class="empty-box">
                    Сұраныс бойынша нысан табылмады. Сүзгіні өзгертіп көріңіз.
                </div>
            <?php else: ?>
                <?php foreach ($filtered_places as $p):
                    $is_active = $selected_place && $selected_place['id'] === $p['id'];
                    $link = 'map.php?' . http_build_query([
                        'q' => $q,
                        'category' => $category,
                        'feature' => $feature,
                        'place' => $p['id']
                    ]);
                ?>
                    <a href="<?= h($link) ?>" class="place-item <?= $is_active ? 'active' : '' ?>">
                        <div class="place-icon"><?= h($p['icon']) ?></div>
                        <div class="place-meta">
                            <strong><?= h($p['name']) ?></strong>
                            <span class="small-muted"><?= h($p['category']) ?> · <?= h($p['address']) ?></span>
                            <div class="mini-tags">
                                <?php if (in_array('Пандус', $p['features'], true)): ?>
                                    <span class="tag-ok">♿ Пандус бар</span>
                                <?php else: ?>
                                    <span class="tag-no">Пандус көрсетілмеген</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <span class="arrow">→</span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Оң жақ: Интерактивті карта макеті -->
        <div class="map-board">
            <div class="board-label">ИНТЕРАКТИВТІ КАРТА МАКЕТІ</div>
            <div class="road road-1"></div>
            <div class="road road-2"></div>
            <div class="park-zone">🌳 Саябақ</div>

            <?php foreach ($filtered_places as $p):
                $is_active = $selected_place && $selected_place['id'] === $p['id'];
                $link = 'map.php?' . http_build_query([
                    'q' => $q,
                    'category' => $category,
                    'feature' => $feature,
                    'place' => $p['id']
                ]);
            ?>
                <a href="<?= h($link) ?>"
                   class="map-pin <?= $is_active ? 'selected' : '' ?>"
                   style="left: <?= (int)$p['x'] ?>%; top: <?= (int)$p['y'] ?>%;"
                   title="<?= h($p['name']) ?>">
                    <?= h($p['icon']) ?>
                </a>
            <?php endforeach; ?>

            <?php if ($selected_place): ?>
                <div class="selected-toast">
                    <?= h($selected_place['icon']) ?> <strong><?= h($selected_place['name']) ?></strong> таңдалды
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Таңдалған нысанның толық сипаттамасы және пікір формасы -->
    <?php if ($selected_place):
        $is_fav = in_array($selected_place['id'], $_SESSION['favorites'], true);
    ?>
        <section class="detail-panel">
            <div class="detail-top">
                <div>
                    <span class="section-kicker">ТАҢДАЛҒАН НЫСАН</span>
                    <h2><?= h($selected_place['icon']) ?> <?= h($selected_place['name']) ?></h2>
                    <p class="small-muted"><?= h($selected_place['address']) ?> · <?= h($selected_place['category']) ?> · 🕒 <?= h($selected_place['hours']) ?> · 📞 <?= h($selected_place['phone']) ?></p>
                </div>
                <form method="post" action="map.php">
                    <input type="hidden" name="action" value="toggle_favorite">
                    <input type="hidden" name="place_id" value="<?= h($selected_place['id']) ?>">
                    <button type="submit" class="btn <?= $is_fav ? 'btn-primary' : 'btn-outline' ?>">
                        <?= $is_fav ? '★ Таңдаулыларда' : '☆ Таңдаулыға қосу' ?>
                    </button>
                </form>
            </div>

            <div class="feature-badges">
                <?php foreach (['Пандус', 'Лифт', 'Арнайы тұрақ'] as $feat):
                    $has = in_array($feat, $selected_place['features'], true);
                ?>
                    <span class="feat-pill <?= $has ? 'yes' : 'no' ?>">
                        <?= $has ? '✓' : '✕' ?> <?= h($feat) ?>
                    </span>
                <?php endforeach; ?>
            </div>

            <p><?= h($selected_place['description']) ?></p>

            <hr class="divider">

            <div class="reviews-grid">
                <div>
                    <h3>Пікірлер (<?= count($place_reviews) ?>)</h3>
                    <?php if (empty($place_reviews)): ?>
                        <p class="small-muted">Бұл нысанға әлі пікір жазылмаған.</p>
                    <?php else: ?>
                        <?php foreach ($place_reviews as $rev): ?>
                            <div class="review-card">
                                <div class="review-head">
                                    <strong><?= h($rev['author']) ?></strong>
                                    <span><?= str_repeat('⭐', (int)$rev['rating']) ?> (<?= (int)$rev['rating'] ?>/5)</span>
                                </div>
                                <p><?= h($rev['comment']) ?></p>
                                <span class="small-muted"><?= h($rev['created_at']) ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div>
                    <h3>Пікір қалдыру (<code>$_POST</code>)</h3>
                    <?php if (!empty($review_errors)): ?>
                        <div class="alert alert-error">
                            <?php foreach ($review_errors as $err): ?>
                                <div>• <?= h($err) ?></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($review_success): ?>
                        <div class="alert alert-success"><?= h($review_success) ?></div>
                    <?php endif; ?>

                    <form method="post" action="map.php" class="stack-form">
                        <input type="hidden" name="action" value="add_review">
                        <input type="hidden" name="place_id" value="<?= h($selected_place['id']) ?>">

                        <label>Аты-жөніңіз</label>
                        <input type="text" name="author" required maxlength="100"
                               value="<?= h($_SESSION['demo_user']['name'] ?? ($_POST['author'] ?? '')) ?>"
                               placeholder="Мысалы: Асқар Б.">

                        <label>Қолжетімділік бағасы (1–5)</label>
                        <select name="rating" required>
                            <option value="5">5 — Өте ыңғайлы</option>
                            <option value="4">4 — Жақсы</option>
                            <option value="3">3 — Орташа</option>
                            <option value="2">2 — Қиындықтар бар</option>
                            <option value="1">1 — Қолжетімсіз</option>
                        </select>

                        <label>Пікір мәтіні</label>
                        <textarea name="comment" rows="3" required placeholder="Пандус немесе кіреберіс жайлы әсеріңіз..."></textarea>

                        <button type="submit" class="btn btn-primary">Пікір жіберу</button>
                    </form>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
