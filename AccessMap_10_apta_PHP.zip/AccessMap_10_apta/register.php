<?php
require_once 'includes/functions.php';

if (is_logged_in()) {
    redirect('map.php');
}

$errors = [];
$full_name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Серверлік валидация
    if ($full_name === '' || mb_strlen($full_name) < 2 || mb_strlen($full_name) > 150) {
        $errors[] = 'Аты-жөніңізді 2–150 таңба аралығында енгізіңіз.';
    }
    if (!valid_email($email)) {
        $errors[] = 'Электрондық пошта пішімі дұрыс емес.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Құпия сөз кемінде 8 таңбадан тұруы тиіс.';
    }
    if ($password !== $password_confirm) {
        $errors[] = 'Құпия сөздер сәйкес келмейді.';
    }

    if (empty($errors)) {
        $_SESSION['demo_user'] = [
            'name' => $full_name,
            'email' => $email,
            'role' => 'user'
        ];
        redirect('map.php');
    }
}

include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card">
        <span class="section-kicker">ACCESSMAP ҚАУЫМДАСТЫҒЫ</span>
        <h1>Аккаунт ашу</h1>
        <p class="small-muted">Серверлік <code>$_POST</code> өңдеу және деректерді тексеру формасы.</p>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?>
                    <div>• <?= h($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="register.php" class="stack-form">
            <label for="full_name">Аты-жөні</label>
            <input id="full_name" type="text" name="full_name" required maxlength="150"
                   value="<?= h($full_name) ?>" placeholder="Аты-жөніңіз">

            <label for="email">Электрондық пошта</label>
            <input id="email" type="email" name="email" required
                   value="<?= h($email) ?>" placeholder="example@mail.com">

            <label for="password">Құпия сөз</label>
            <input id="password" type="password" name="password" required minlength="8"
                   placeholder="Кемінде 8 таңба">

            <label for="password_confirm">Құпия сөзді қайталау</label>
            <input id="password_confirm" type="password" name="password_confirm" required minlength="8"
                   placeholder="Құпия сөзді қайта енгізіңіз">

            <button type="submit" class="btn btn-primary btn-block">Тіркелуді тексеру</button>
        </form>

        <p class="auth-switch">Аккаунтыңыз бар ма? <a href="login.php">Кіру</a></p>
        <p class="small-muted">10-апта прототипі: деректер PHP сессиясында сақталады, MySQL дерекқоры 11-аптада қосылады.</p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
