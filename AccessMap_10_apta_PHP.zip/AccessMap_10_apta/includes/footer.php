</main>
<footer class="site-footer">
    <div class="container footer-wrap">
        <div>
            <strong>✦ AccessMap</strong> — Мүмкіндігі шектеулі адамдарға арналған қолжетімді нысандардың интерактивті картасы.
        </div>
        <div class="footer-note">
            10-апта: PHP негіздері және серверлік құрылым (include, $_POST, $_GET, серверлік валидация)
        </div>
    </div>
</footer>
</body>
</html>
