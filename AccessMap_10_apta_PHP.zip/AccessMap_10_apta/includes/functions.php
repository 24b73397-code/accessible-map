<?php
session_start();

// Демонстрациялық бастапқы нысандар (9-аптадағы каталог деректері негізінде)
if (!isset($_SESSION['places'])) {
    $_SESSION['places'] = [
        [
            'id' => 'place_1',
            'name' => 'Үлгі емхана',
            'category' => 'Медицина',
            'address' => 'Демо аймақ, 1-нысан',
            'phone' => '+7 (727) 250-10-01',
            'hours' => '08:00 – 20:00',
            'features' => ['Пандус', 'Лифт', 'Арнайы тұрақ'],
            'x' => 24,
            'y' => 28,
            'icon' => '🏥',
            'description' => 'Кіреберісте нормативтік көлбеу пандус, кең лифт және мүгедектігі бар жандарға арналған тұрақ орны бар.'
        ],
        [
            'id' => 'place_2',
            'name' => 'Үлгі кітапхана',
            'category' => 'Білім беру',
            'address' => 'Демо аймақ, 2-нысан',
            'phone' => '+7 (727) 250-20-02',
            'hours' => '09:00 – 19:00',
            'features' => ['Пандус'],
            'x' => 68,
            'y' => 24,
            'icon' => '📚',
            'description' => 'Оқу залына кіретін пандус бар. Екінші қабатқа көтерілетін лифт әзірге жоқ.'
        ],
        [
            'id' => 'place_3',
            'name' => 'Үлгі дәріхана',
            'category' => 'Медицина',
            'address' => 'Демо аймақ, 3-нысан',
            'phone' => '+7 (727) 250-30-03',
            'hours' => 'Тәулік бойы',
            'features' => ['Пандус', 'Арнайы тұрақ'],
            'x' => 45,
            'y' => 52,
            'icon' => '💊',
            'description' => 'Төмен табалдырықты кіреберіс, пандус және жақын орналасқан арнайы тұрақ қарастырылған.'
        ],
        [
            'id' => 'place_4',
            'name' => 'Үлгі сауда орталығы',
            'category' => 'Сауда',
            'address' => 'Демо аймақ, 4-нысан',
            'phone' => '+7 (727) 250-40-04',
            'hours' => '10:00 – 22:00',
            'features' => ['Пандус', 'Лифт', 'Арнайы тұрақ'],
            'x' => 76,
            'y' => 74,
            'icon' => '🛍️',
            'description' => 'Барлық қабаттарға арналған кең лифттер, пандустар және белгіленген тұрақ орындары бар.'
        ],
        [
            'id' => 'place_5',
            'name' => 'Үлгі мәдениет үйі',
            'category' => 'Мәдениет',
            'address' => 'Демо аймақ, 5-нысан',
            'phone' => '+7 (727) 250-50-05',
            'hours' => '09:00 – 21:00',
            'features' => [],
            'x' => 28,
            'y' => 76,
            'icon' => '🎭',
            'description' => 'Ғимаратта пандус пен лифт әлі орнатылмаған, кіреберісте баспалдақ бар.'
        ]
    ];
}

if (!isset($_SESSION['favorites'])) {
    $_SESSION['favorites'] = ['place_1'];
}

if (!isset($_SESSION['reviews'])) {
    $_SESSION['reviews'] = [
        [
            'place_id' => 'place_1',
            'author' => 'Айгүл С.',
            'rating' => 5,
            'comment' => 'Пандус өте ыңғайлы жасалған, лифт кең.',
            'created_at' => '2026-11-15'
        ],
        [
            'place_id' => 'place_2',
            'author' => 'Ерлан Т.',
            'rating' => 4,
            'comment' => 'Бірінші қабатқа кіру оңай, бірақ екінші қабатқа лифт қажет.',
            'created_at' => '2026-11-16'
        ]
    ];
}

function h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function redirect($page) {
    header('Location: ' . $page);
    exit;
}

function valid_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function is_logged_in() {
    return !empty($_SESSION['demo_user']);
}

function current_page() {
    return basename($_SERVER['PHP_SELF']);
}
?>
