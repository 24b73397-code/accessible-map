<?php
if (!function_exists('h')) {
    require_once __DIR__ . '/functions.php';
}
$page = current_page();
?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AccessMap — Қолжетімді нысандардың интерактивті картасы</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a href="index.php" class="brand">
            <span class="brand-icon">✦</span>
            <span>AccessMap</span>
        </a>
        <nav class="main-nav">
            <a href="index.php" class="<?= $page === 'index.php' ? 'active' : '' ?>">Басты бет</a>
            <a href="map.php" class="<?= $page === 'map.php' ? 'active' : '' ?>">Нысандар картасы</a>
            <?php if (is_logged_in()): ?>
                <a href="add_place.php" class="<?= $page === 'add_place.php' ? 'active' : '' ?>">+ Нысан қосу</a>
                <a href="favorites.php" class="<?= $page === 'favorites.php' ? 'active' : '' ?>">Таңдаулылар (<?= count($_SESSION['favorites']) ?>)</a>
                <span class="user-pill">👤 <?= h($_SESSION['demo_user']['name']) ?></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Шығу</a>
            <?php else: ?>
                <a href="login.php" class="<?= $page === 'login.php' ? 'active' : '' ?>">Кіру</a>
                <a href="register.php" class="btn btn-primary btn-sm">Тіркелу</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="main-content">
