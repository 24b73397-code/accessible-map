<?php
require_once 'includes/functions.php';
include 'includes/header.php';
?>
<div class="container">
    <section class="hero-grid">
        <div class="hero-text">
            <span class="pill-badge">♿ КЕДЕРГІСІЗ ОРТА — БӘРІМІЗГЕ ОРТАҚ</span>
            <h1>Қаладағы әр орын <span class="text-blue">қолжетімді</span> болсын</h1>
            <p class="lead">
                AccessMap — қоғамдық нысандардың пандус, лифт, арнайы тұрақ және басқа қолжетімділік мүмкіндіктерін алдын ала қарауға арналған веб-жоба.
            </p>
            <div class="hero-actions">
                <a href="map.php" class="btn btn-primary">🗺️ Картаны ашу</a>
                <a href="#how-it-works" class="btn btn-outline">Қалай жұмыс істейді?</a>
            </div>
            <p class="muted-note">
                10-апта прототипі: беттер PHP файлдарына бөлінді, <code>include</code> арқылы ортақ header/footer және серверлік форма өңдеу қосылды.
            </p>
        </div>

        <div class="hero-card-visual">
            <div class="map-preview-card">
                <div class="floating-tag tag-top">✓ Пандус</div>
                <div class="floating-tag tag-right">♿ Арнайы тұрақ</div>
                <div class="floating-tag tag-bottom">🧭 Бағыт</div>
                <div class="map-emoji">🗺️</div>
                <p class="small-muted">Интерактивті қолжетімділік каталогы</p>
            </div>
        </div>
    </section>

    <section id="how-it-works" class="section-block">
        <div class="section-center">
            <span class="section-kicker">ҚАРАПАЙЫМ ЖӘНЕ ЫҢҒАЙЛЫ</span>
            <h2>AccessMap қалай көмектеседі?</h2>
        </div>

        <div class="cards-3">
            <div class="info-card">
                <div class="icon-box">🔍</div>
                <h3>Нысанды іздеу</h3>
                <p>Емхана, дәріхана, кітапхана және басқа орындарды атауы немесе санаты бойынша <code>$_GET</code> сүзгісі арқылы іздеңіз.</p>
            </div>
            <div class="info-card">
                <div class="icon-box">♿</div>
                <h3>Қолжетімділікті көру</h3>
                <p>Пандус, лифт және арнайы тұрақ туралы серверде өңделген ақпаратты салыстырыңыз.</p>
            </div>
            <div class="info-card">
                <div class="icon-box">📍</div>
                <h3>Картадан қарау және пікір жазу</h3>
                <p>Нысан карточкасын таңдап, карта макетінде орнын көріңіз және <code>$_POST</code> арқылы пікір қалдырыңыз.</p>
            </div>
        </div>
    </section>

    <section class="cta-banner">
        <div>
            <span class="section-kicker">НЫСАНДАР КАТАЛОГЫ</span>
            <h2>Қолжетімді орта жайлы ақпарат — бір жерде</h2>
            <p>Санат және қолжетімділік белгілері бойынша сүзгілерді қолданып, нысан сипаттамасын көріңіз.</p>
            <a href="map.php" class="btn btn-primary">Нысандарды қарау →</a>
        </div>
        <div class="cta-icons">🏥 📚 🏛️</div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>
