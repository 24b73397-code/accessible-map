<?php
require_once 'includes/functions.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$errors = [];
$name = '';
$category = 'Медицина';
$address = '';
$phone = '';
$hours = '09:00 – 18:00';
$description = '';
$selected_features = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $hours = trim($_POST['hours'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $selected_features = $_POST['features'] ?? [];

    if ($name === '' || mb_strlen($name) > 200) {
        $errors[] = 'Нысан атауын 1–200 таңба аралығында енгізіңіз.';
    }
    if (!in_array($category, ['Медицина', 'Білім беру', 'Сауда', 'Мәдениет'], true)) {
        $errors[] = 'Дұрыс санатты таңдаңыз.';
    }
    if ($address === '' || mb_strlen($address) > 255) {
        $errors[] = 'Мекенжайды енгізіңіз.';
    }

    if (empty($errors)) {
        $icons = [
            'Медицина' => '🏥',
            'Білім беру' => '📚',
            'Сауда' => '🛍️',
            'Мәдениет' => '🎭'
        ];
        $new_id = 'place_' . (count($_SESSION['places']) + 1);
        $_SESSION['places'][] = [
            'id' => $new_id,
            'name' => $name,
            'category' => $category,
            'address' => $address,
            'phone' => $phone ?: '+7 (727) 000-00-00',
            'hours' => $hours ?: '09:00 – 18:00',
            'features' => array_values(array_intersect($selected_features, ['Пандус', 'Лифт', 'Арнайы тұрақ'])),
            'x' => rand(20, 80),
            'y' => rand(20, 80),
            'icon' => $icons[$category] ?? '📍',
            'description' => $description ?: 'Пайдаланушы қосқан қолжетімділік нысаны.'
        ];
        redirect('map.php?place=' . urlencode($new_id));
    }
}

include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card" style="max-width: 560px;">
        <span class="section-kicker">ЖАҢА НЫСАН ҚОСУ</span>
        <h1>Қолжетімді нысанды тіркеу</h1>
        <p class="small-muted">Деректер <code>$_POST</code> арқылы жіберіліп, серверде тексеріледі.</p>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?>
                    <div>• <?= h($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="add_place.php" class="stack-form">
            <label>Нысан атауы *</label>
            <input type="text" name="name" required maxlength="200" value="<?= h($name) ?>" placeholder="Мысалы: №5 Қалалық емхана">

            <label>Санаты *</label>
            <select name="category" required>
                <?php foreach (['Медицина', 'Білім беру', 'Сауда', 'Мәдениет'] as $cat): ?>
                    <option value="<?= h($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= h($cat) ?></option>
                <?php endforeach; ?>
            </select>

            <label>Мекенжайы *</label>
            <input type="text" name="address" required maxlength="255" value="<?= h($address) ?>" placeholder="Мысалы: Абай даңғылы, 44">

            <label>Байланыс телефоны</label>
            <input type="text" name="phone" value="<?= h($phone) ?>" placeholder="+7 (727) 250-00-00">

            <label>Жұмыс уақыты</label>
            <input type="text" name="hours" value="<?= h($hours) ?>" placeholder="09:00 – 18:00">

            <label>Қолжетімділік ерекшеліктері</label>
            <div class="checkbox-row">
                <?php foreach (['Пандус', 'Лифт', 'Арнайы тұрақ'] as $feat): ?>
                    <label class="check-item">
                        <input type="checkbox" name="features[]" value="<?= h($feat) ?>"
                            <?= in_array($feat, $selected_features, true) ? 'checked' : '' ?>>
                        <span><?= h($feat) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>

            <label>Сипаттама</label>
            <textarea name="description" rows="3" placeholder="Кіреберіс пен жабдықталуы туралы қысқаша ақпарат..."><?= h($description) ?></textarea>

            <button type="submit" class="btn btn-primary btn-block">Нысанды сақтау</button>
        </form>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
