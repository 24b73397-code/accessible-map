<?php
require_once 'includes/functions.php';

if (!is_logged_in()) {
    redirect('login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'remove_fav') {
    $remove_id = $_POST['place_id'] ?? '';
    $_SESSION['favorites'] = array_values(array_diff($_SESSION['favorites'], [$remove_id]));
}

$fav_places = [];
foreach ($_SESSION['places'] as $p) {
    if (in_array($p['id'], $_SESSION['favorites'], true)) {
        $fav_places[] = $p;
    }
}

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">ЖЕКЕ ТІЗІМ</span>
        <h1>Таңдаулы нысандар</h1>
        <p class="small-muted">Пайдаланушы сақтаған қолжетімді орындар тізімі.</p>
    </div>

    <?php if (empty($fav_places)): ?>
        <div class="empty-box">
            Таңдаулылар тізімі әзірге бос. <a href="map.php">Картадан нысан таңдаңыз →</a>
        </div>
    <?php else: ?>
        <div class="cards-3">
            <?php foreach ($fav_places as $p): ?>
                <div class="info-card">
                    <div class="icon-box"><?= h($p['icon']) ?></div>
                    <h3><?= h($p['name']) ?></h3>
                    <p class="small-muted"><?= h($p['category']) ?> · <?= h($p['address']) ?></p>
                    <p><?= h($p['description']) ?></p>
                    <div class="hero-actions" style="margin-top: 12px;">
                        <a href="map.php?place=<?= urlencode($p['id']) ?>" class="btn btn-primary btn-sm">Картадан ашу</a>
                        <form method="post" action="favorites.php" style="display:inline;">
                            <input type="hidden" name="action" value="remove_fav">
                            <input type="hidden" name="place_id" value="<?= h($p['id']) ?>">
                            <button type="submit" class="btn btn-outline btn-sm">Жою</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
