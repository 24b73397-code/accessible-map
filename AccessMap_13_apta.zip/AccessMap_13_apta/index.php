<?php
require_once 'includes/functions.php';
include 'includes/header.php';

$places_count = (int)$pdo->query("SELECT COUNT(*) FROM Places")->fetchColumn();
$users_count  = (int)$pdo->query("SELECT COUNT(*) FROM Users")->fetchColumn();
$reviews_count = (int)$pdo->query("SELECT COUNT(*) FROM Reviews")->fetchColumn();
?>
<div class="container">
    <section class="hero-grid">
        <div class="hero-text">
            <span class="pill-badge">🔍 13-АПТА · ІЗДЕУ, СҮЗУ ЖӘНЕ ПАГИНАЦИЯ</span>
            <h1>Деректермен жұмыс: Серверлік <span class="text-blue">іздеу, сүзу және пагинация</span></h1>
            <p class="lead">
                AccessMap жобасының 13-аптасында нысандарды мәтін бойынша іздеу, санат пен қосылған дата бойынша сүзу (filtering), әр түрлі бағытта сұрыптау (sorting) және нәтижелерді беттерге бөлу (pagination) функциялары толық іске асырылды.
            </p>
            <div class="hero-actions">
                <a href="map.php" class="btn btn-primary">🗺️ Кеңейтілген каталогқа өту (<?= $places_count ?> нысан)</a>
                <?php if (is_logged_in()): ?>
                    <a href="add_place.php" class="btn btn-outline">+ Жаңа нысан қосу</a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-outline">Аккаунт ашу</a>
                <?php endif; ?>
            </div>
            <p class="muted-note">Жүйедегі тіркелген қолданушылар: <strong><?= $users_count ?></strong>, жазылған пікірлер: <strong><?= $reviews_count ?></strong>.</p>
        </div>
        <div class="hero-card-visual">
            <div class="map-preview-card">
                <div class="floating-tag tag-top">🔍 Server Search & Filter</div>
                <div class="floating-tag tag-right">📊 Sorting & Date</div>
                <div class="floating-tag tag-bottom">📄 Pagination (Page 1 of X)</div>
                <div class="map-emoji">🎛️</div>
                <p class="small-muted">13-апта функционалы</p>
            </div>
        </div>
    </section>

    <section class="section-block">
        <div class="section-center">
            <span class="section-kicker">13-АПТА МҮМКІНДІКТЕРІ</span>
            <h2>Деректермен жұмыс және сұраныстарды оңтайландыру</h2>
        </div>
        <div class="cards-3">
            <div class="info-card">
                <div class="icon-box">🔍</div>
                <h3>1. Іздеу және Сүзу</h3>
                <p>Нысан атауы мен мекенжайы бойынша мәтіндік іздеу, санат (Categories) және қосылған датасы бойынша нақты сүзу (filtering).</p>
            </div>
            <div class="info-card">
                <div class="icon-box">📊</div>
                <h3>2. Сұрыптау (Sorting)</h3>
                <p>Нысандарды атауы бойынша (А-Я, Я-А), жаңа/ескі қосылғаны бойынша немесе ID көрсеткішіне сай реттеу.</p>
            </div>
            <div class="info-card">
                <div class="icon-box">📄</div>
                <h3>3. Пагинация (Pagination)</h3>
                <p>Үлкен деректер базасымен жұмыс істеу үшін нәтижелерді беттерге бөліп көрсету (әр бетте 5 нысаннан).</p>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>