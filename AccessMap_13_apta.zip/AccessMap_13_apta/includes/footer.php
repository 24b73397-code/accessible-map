</main>
<footer class="site-footer">
    <div class="container footer-wrap">
        <div><strong>✦ AccessMap</strong> — Мүмкіндігі шектеулі жандарға арналған қолжетімді нысандар каталогы.</div>
        <div class="footer-note">13-апта: Серверлік іздеу, сүзу (санат, дата), сұрыптау және пагинация</div>
    </div>
</footer>
</body>
</html>