<?php
require_once 'includes/functions.php';
require_login();

$categories = $pdo->query("SELECT * FROM Categories")->fetchAll();
$all_features = $pdo->query("SELECT * FROM AccessibilityFeatures")->fetchAll();

$errors = [];
$name = '';
$address = '';
$phone = '';
$opening_hours = '09:00 – 18:00';
$description = '';
$category_id = 1;
$selected_features = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 1);
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $opening_hours = trim($_POST['opening_hours'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $selected_features = array_map('intval', $_POST['features'] ?? []);

    if ($name === '') { $errors[] = 'Нысан атауы міндетті.'; }
    if ($address === '') { $errors[] = 'Мекенжай міндетті.'; }

    if (empty($errors)) {
        $icons = [1 => '🏥', 2 => '📚', 3 => '🛍️', 4 => '🎭'];
        $icon = $icons[$category_id] ?? '📍';

        $stmt = $pdo->prepare("INSERT INTO Places (name, category_id, address, phone, opening_hours, description, map_x, map_y, icon, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            $name,
            $category_id,
            $address,
            $phone ?: '+7 (727) 250-00-00',
            $opening_hours,
            $description ?: 'Пайдаланушы қосқан нысан.',
            rand(20, 80),
            rand(20, 80),
            $icon,
            current_user()['user_id']
        ]);
        $new_id = (int)$pdo->lastInsertId();

        if (!empty($selected_features)) {
            $stmtF = $pdo->prepare("INSERT IGNORE INTO PlaceFeatures (place_id, feature_id, availability_status) VALUES (?, ?, 'available')");
            foreach ($selected_features as $fid) {
                $stmtF->execute([$new_id, $fid]);
            }
        }
        redirect('map.php?place=' . $new_id);
    }
}
include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card" style="max-width:560px;">
        <span class="section-kicker">CREATE PLACE</span>
        <h1>Жаңа нысан қосу</h1>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?><div>• <?= h($e) ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="post" class="stack-form">
            <label>Нысан атауы *</label>
            <input type="text" name="name" required value="<?= h($name) ?>" placeholder="Мысалы: Орталық емхана">
            <label>Санаты *</label>
            <select name="category_id">
                <?php foreach ($categories as $c): ?>
                    <option value="<?= (int)$c['category_id'] ?>" <?= $category_id === (int)$c['category_id'] ? 'selected' : '' ?>><?= h($c['category_name']) ?></option>
                <?php endforeach; ?>
            </select>
            <label>Мекенжайы *</label>
            <input type="text" name="address" required value="<?= h($address) ?>" placeholder="Мысалы: Достық даңғылы, 15">
            <label>Телефон</label>
            <input type="text" name="phone" value="<?= h($phone) ?>" placeholder="+7 (727) ...">
            <label>Жұмыс уақыты</label>
            <input type="text" name="opening_hours" value="<?= h($opening_hours) ?>" placeholder="09:00 – 18:00">
            <label>Қолжетімділік ерекшеліктері</label>
            <div class="checkbox-row">
                <?php foreach ($all_features as $f): ?>
                    <label class="check-item">
                        <input type="checkbox" name="features[]" value="<?= (int)$f['feature_id'] ?>">
                        <span><?= h($f['feature_name']) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <label>Сипаттама</label>
            <textarea name="description" rows="3" placeholder="Нысан туралы сипаттама..."><?= h($description) ?></textarea>
            <button type="submit" class="btn btn-primary btn-block">Дерекқорға сақтау</button>
        </form>
    </div>
</div>
<?php include 'includes/footer.php'; ?>