<?php
require_once 'includes/functions.php';
include 'includes/header.php';

$places_count = (int)$pdo->query("SELECT COUNT(*) FROM Places")->fetchColumn();
$users_count  = (int)$pdo->query("SELECT COUNT(*) FROM Users")->fetchColumn();
$reviews_count = (int)$pdo->query("SELECT COUNT(*) FROM Reviews")->fetchColumn();
?>
<div class="container">
    <section class="hero-grid">
        <div class="hero-text">
            <span class="pill-badge">🚀 15-АПТА · ҚОРЫТЫНДЫ КЕЗЕҢ (ТЕСТІЛЕУ ЖӘНЕ ХОСТИНГ)</span>
            <h1>AccessMap жобасының <span class="text-blue">соңғы нұсқасы</span></h1>
            <p class="lead">
                Жобамыз барлық тестілеу кезеңдерінен сәтті өтіп, код тазартылды және тегін хостингке (InfinityFree / XAMPP) орналастыруға дайындалды. Қауіпсіздік шаралары (XSS, SQL Injection, File Validation) толықтай тексерілді.
            </p>
            <div class="hero-actions">
                <a href="map.php" class="btn btn-primary">🗺️ Нысандар каталогы мен карта</a>
                <a href="defense.php" class="btn btn-outline" style="border-color:#13733c;color:#13733c;">🎯 Қорғау материалы (Презентация)</a>
            </div>
            <p class="muted-note" style="margin-top:16px;">Қолданушылар: <strong><?= $users_count ?></strong> | Нысандар: <strong><?= $places_count ?></strong> | Пікірлер: <strong><?= $reviews_count ?></strong></p>
        </div>
        <div class="hero-card-visual">
            <div class="map-preview-card">
                <div class="floating-tag tag-top">🌐 Hosting Ready</div>
                <div class="floating-tag tag-right">🛡️ Tested & Secured</div>
                <div class="floating-tag tag-bottom">🎓 Final Defense 100%</div>
                <div class="map-emoji">🚀</div>
                <p class="small-muted">15-апта нәтижесі</p>
            </div>
        </div>
    </section>

    <section class="section-block">
        <div class="section-center">
            <span class="section-kicker">15-АПТА ТАЛАПТАРЫ</span>
            <h2>Орындалған жұмыстардың қысқаша шолуы</h2>
        </div>
        <div class="cards-3">
            <div class="info-card">
                <div class="icon-box">🔍</div>
                <h3>1. Тестілеу және түзету</h3>
                <p>Барлық CRUD операциялары, пагинация, іздеу, сүзу, сондай-ақ файл жүктеу қауіпсіздігі толық тексеріліп, ақаулар жойылды.</p>
            </div>
            <div class="info-card">
                <div class="icon-box">🌐</div>
                <h3>2. Хостингке орналастыру</h3>
                <p>Файлдар архивтеліп, дерекқор (`accessmap.sql`) phpMyAdmin арқылы импорттауға дайындалды. Хостинг баптаулары қаралды.</p>
            </div>
            <div class="info-card">
                <div class="icon-box">🎓</div>
                <h3>3. Қорытынды қорғау</h3>
                <p>5-7 минуттық презентация құрылымы, демонтрация сценарийі және сұрақ-жауаптарға дайындық жасалды.</p>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>