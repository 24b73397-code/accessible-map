<?php
require_once 'includes/functions.php';
require_login();
$review_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$place_id = filter_var($_GET['place_id'] ?? 0, FILTER_VALIDATE_INT);
if ($review_id) {
    $stmt = $pdo->prepare("SELECT user_id, place_id FROM Reviews WHERE review_id = ?");
    $stmt->execute([$review_id]);
    $rev = $stmt->fetch();
    if ($rev && (is_admin() || (int)$rev['user_id'] === (int)current_user()['user_id'])) {
        $pdo->prepare("DELETE FROM Reviews WHERE review_id = ?")->execute([$review_id]);
        $place_id = $rev['place_id'];
    }
}
redirect('map.php' . ($place_id ? '?place=' . $place_id : ''));
?>