<?php
require_once 'includes/functions.php';
if (is_logged_in()) { redirect('profile.php'); }

$errors = [];
$full_name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if ($full_name === '' || mb_strlen($full_name) < 2) { $errors[] = 'Аты-жөніңізді дұрыс енгізіңіз.'; }
    if (!valid_email($email)) { $errors[] = 'Электрондық пошта қате пішімде.'; }
    if (strlen($password) < 8) { $errors[] = 'Құпия сөз кемінде 8 таңба болуы тиіс.'; }
    if ($password !== $password_confirm) { $errors[] = 'Құпия сөздер сәйкес келмейді.'; }

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT user_id FROM Users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Бұл email бұрын тіркелген.';
        } else {
            $total = (int)$pdo->query("SELECT COUNT(*) FROM Users")->fetchColumn();
            $role = ($total === 0) ? 'admin' : 'user';
            $p_hash = password_hash($password, PASSWORD_DEFAULT);

            $ins = $pdo->prepare("INSERT INTO Users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)");
            $ins->execute([$full_name, $email, $p_hash, $role]);
            
            $_SESSION['user'] = [
                'user_id' => (int)$pdo->lastInsertId(),
                'full_name' => $full_name,
                'email' => $email,
                'role' => $role,
                'avatar' => 'default_avatar.png'
            ];
            redirect('profile.php');
        }
    }
}
include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card">
        <span class="section-kicker">РЕГИСТРАЦИЯ</span>
        <h1>Аккаунт ашу</h1>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?><div>• <?= h($e) ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="post" class="stack-form">
            <label>Аты-жөні</label>
            <input type="text" name="full_name" required value="<?= h($full_name) ?>" placeholder="Толық атыңыз">
            <label>Email</label>
            <input type="email" name="email" required value="<?= h($email) ?>" placeholder="mail@example.com">
            <label>Құпия сөз</label>
            <input type="password" name="password" required minlength="8" placeholder="Кемінде 8 таңба">
            <label>Құпия сөзді қайталаңыз</label>
            <input type="password" name="password_confirm" required minlength="8" placeholder="Құпия сөзді растаңыз">
            <button type="submit" class="btn btn-primary btn-block">Тіркелу</button>
        </form>
        <p class="auth-switch">Аккаунтыңыз бар ма? <a href="login.php">Кіру</a></p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>