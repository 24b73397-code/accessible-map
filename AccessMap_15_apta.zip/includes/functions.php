<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

function h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function redirect($page) {
    header('Location: ' . $page);
    exit;
}

function valid_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function is_logged_in() {
    return !empty($_SESSION['user']) && !empty($_SESSION['user']['user_id']);
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function is_admin() {
    return is_logged_in() && (($_SESSION['user']['role'] ?? 'user') === 'admin');
}

function require_login() {
    if (!is_logged_in()) {
        $_SESSION['flash_error'] = 'Бұл бетке өту үшін алдымен жүйеге кіріңіз.';
        redirect('login.php');
    }
}

function require_admin() {
    if (!is_admin()) {
        $_SESSION['flash_error'] = 'Бұл әрекет тек әкімшіге (admin) рұқсат етілген.';
        redirect('map.php');
    }
}

function current_page() {
    return basename($_SERVER['PHP_SELF']);
}

function upload_image_safely($file_input_name) {
    if (!isset($_FILES[$file_input_name]) || $_FILES[$file_input_name]['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => true, 'filename' => null];
    }

    $file = $_FILES[$file_input_name];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'Файлды жүктеу барысында қате орын алды.'];
    }

    if ($file['size'] > 2 * 1024 * 1024) {
        return ['success' => false, 'error' => 'Файл өлшемі 2MB-тан аспауы тиіс.'];
    }

    $allowed_mimes = ['image/jpeg', 'image/png', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime_type, $allowed_mimes)) {
        return ['success' => false, 'error' => 'Тек JPG, PNG немесе WEBP форматындағы суреттер қабылданады.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $upload_dir = __DIR__ . '/../uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    $new_filename = 'img_' . uniqid() . '_' . time() . '.' . $ext;
    $destination = $upload_dir . $new_filename;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => true, 'filename' => $new_filename];
    }

    return ['success' => false, 'error' => 'Файлды серверге сақтау сәтсіз аяқталды.'];
}
?>