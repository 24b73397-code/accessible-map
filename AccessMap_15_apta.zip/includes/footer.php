</main>
<footer class="site-footer">
    <div class="container footer-wrap">
        <div><strong>✦ AccessMap</strong> — Мүмкіндігі шектеулі жандарға арналған қолжетімді нысандар каталогы.</div>
        <div class="footer-note">15-апта: Тестілеу, Хостинг және Қорытынды қорғау</div>
    </div>
</footer>
</body>
</html>