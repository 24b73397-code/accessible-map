<?php
// 15-апта: Хостингке арналған динамикалық конфигурация (InfinityFree / Localhost)
$host = 'localhost';
$dbname = 'accessmap_db';
$username = 'root';
$password = '';

// Егер сервер хостингте болса (мысалы, InfinityFree немесе басқа)
if ($_SERVER['HTTP_HOST'] !== 'localhost:8080' && $_SERVER['HTTP_HOST'] !== 'localhost') {
    // Хостинг деректерін осында өзгертуге болады
    // $host = 'sql100.infinityfree.com';
    // $dbname = 'if0_xxxxxxx_accessmap';
    // $username = 'if0_xxxxxxx';
    // $password = 'сіздің_құпия_сөзіңіз';
}

$dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    die('<div style="font-family:Arial;max-width:640px;margin:40px auto;padding:24px;border:1px solid #f5c2c2;background:#fdecec;border-radius:12px;color:#842029;">
        <h2 style="margin-top:0;">Дерекқорға қосылу қатесі (Database Connection Error)</h2>
        <p>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p>
        <p style="font-size:13px;color:#555;">Хостинг немесе XAMPP баптауларындағы дерекқор атауын, логин мен парольді тексеріңіз.</p>
    </div>');
}
?>