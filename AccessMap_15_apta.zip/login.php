<?php
require_once 'includes/functions.php';
if (is_logged_in()) { redirect('profile.php'); }

$errors = [];
$email = '';
if (!empty($_SESSION['flash_error'])) {
    $errors[] = $_SESSION['flash_error'];
    unset($_SESSION['flash_error']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT user_id, full_name, email, password_hash, role, avatar FROM Users WHERE email = ?");
    $stmt->execute([$email]);
    $u = $stmt->fetch();

    if ($u && password_verify($password, $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'user_id' => (int)$u['user_id'],
            'full_name' => $u['full_name'],
            'email' => $u['email'],
            'role' => $u['role'],
            'avatar' => $u['avatar'] ?: 'default_avatar.png'
        ];
        redirect('profile.php');
    } else {
        $errors[] = 'Email немесе құпия сөз қате.';
    }
}
include 'includes/header.php';
?>
<div class="auth-wrapper">
    <div class="auth-card">
        <span class="section-kicker">АУТЕНТИФИКАЦИЯ</span>
        <h1>Жүйеге кіру</h1>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $e): ?><div>• <?= h($e) ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="post" class="stack-form">
            <label>Email</label>
            <input type="email" name="email" required value="<?= h($email) ?>" placeholder="mail@example.com">
            <label>Құпия сөз</label>
            <input type="password" name="password" required placeholder="Құпия сөзіңіз">
            <button type="submit" class="btn btn-primary btn-block">Кіру</button>
        </form>
        <p class="auth-switch">Аккаунтыңыз жоқ па? <a href="register.php">Тіркелу</a></p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>