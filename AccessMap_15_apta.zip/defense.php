<?php
require_once 'includes/functions.php';
include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">15-АПТА · ЖОБАНЫ ҚОРҒАУ ЖӘНЕ ПРЕЗЕНТАЦИЯ</span>
        <h1>AccessMap жобасын қорғау материалдары</h1>
        <p class="small-muted">Бұл бетте жобаның 5-7 минуттық қорғауына арналған слайдтар құрылымы мен негізгі тезистер жинақталған.</p>
    </div>

    <div class="cards-3" style="grid-template-columns: 1fr 1fr; margin-bottom:24px;">
        <div class="info-card">
            <h3> слайд 1–2: Кіріспе және өзектілік</h3>
            <ul style="padding-left:18px; margin-top:8px; font-size:14px; color:#445b75;">
                <li><strong>Жоба атауы:</strong> AccessMap — Мүмкіндігі шектеулі жандарға арналған интерактивті карта мен каталог.</li>
                <li><strong>Мәселе:</strong> Қаладағы пандустар, лифттер мен арнайы тұрақтар туралы толық ақпараттың болмауы.</li>
                <li><strong>Мақсаты:</strong> Қолжетімді нысандарды орталықтандырылған түрде іздеу, бағалау және басқару жүйесін құру.</li>
            </ul>
        </div>
        <div class="info-card">
            <h3> слайд 3–4: Технологиялық стек</h3>
            <ul style="padding-left:18px; margin-top:8px; font-size:14px; color:#445b75;">
                <li><strong>Backend:</strong> PHP 8+, PDO (Prepared Statements арқылы SQL инъекциясынан қорғау).</li>
                <li><strong>Database:</strong> MySQL (Relational DB, Foreign Keys, Cascade Delete).</li>
                <li><strong>Frontend:</strong> HTML5, CSS3 (Responsive Design, Flexbox/Grid), JavaScript.</li>
                <li><strong>Environment:</strong> XAMPP локальді сервері және InfinityFree/тегін хостинг.</li>
            </ul>
        </div>
        <div class="info-card">
            <h3> слайд 5–6: Негізгі функциялар</h3>
            <ul style="padding-left:18px; margin-top:8px; font-size:14px; color:#445b75;">
                <li>Қауіпсіз авторлық аутентификация (Password hashing).</li>
                <li>Мәтіндік іздеу, санат және мүмкіндіктер бойынша сүзу (Filtering).</li>
                <li>Пагинация және сұрыптау (Sorting).</li>
                <li>Нысандарға пікір жазу, бағалау және таңдаулыларға қосу.</li>
                <li>Профиль аватарын қауіпсіз жүктеу (MIME type check) және Әкімші панелі.</li>
            </ul>
        </div>
        <div class="info-card">
            <h3> слайд 7–8: Қауіпсіздік және қорытынды</h3>
            <ul style="padding-left:18px; margin-top:8px; font-size:14px; color:#445b75;">
                <li><strong>XSS қорғанысы:</strong> Барлық шығатын деректер `htmlspecialchars()` арқылы экранылады.</li>
                <li><strong>Файл қауіпсіздігі:</strong> 2MB лимит және финфо арқылы формалды түр тексерісі.</li>
                <li><strong>Қорытынды:</strong> Жоба 100% аяқталып, хостингке сәтті орналастырылды.</li>
            </ul>
        </div>
    </div>

    <div class="places-column" style="padding:24px; text-align:center;">
        <h3>🎯 Демонстрация сценарийі (Live Demo)</h3>
        <p style="max-width:700px; margin:10px auto; color:#556b82; font-size:14px;">
            Қорғау кезінде басты беттен іздеу жасап, картадан нысанды таңдап, пікір қалдырып, содан кейін <code>admin.php</code> арқылы рөлдерді басқару мүмкіндігін көрсетіңіз.
        </p>
        <div style="margin-top:16px;">
            <a href="map.php" class="btn btn-primary">🗺️ Демонстрацияны бастау (Каталог)</a>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>