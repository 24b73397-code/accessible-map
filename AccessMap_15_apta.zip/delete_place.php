<?php
require_once 'includes/functions.php';
require_login();
$place_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
if ($place_id) {
    $stmt = $pdo->prepare("SELECT created_by FROM Places WHERE place_id = ?");
    $stmt->execute([$place_id]);
    $place = $stmt->fetch();
    if ($place && (is_admin() || (int)$place['created_by'] === (int)current_user()['user_id'])) {
        $pdo->prepare("DELETE FROM Places WHERE place_id = ?")->execute([$place_id]);
    }
}
redirect('map.php');
?>