<?php
require_once 'includes/functions.php';
require_login();
require_admin();

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'change_role') {
        $target_user_id = filter_var($_POST['user_id'] ?? 0, FILTER_VALIDATE_INT);
        $new_role = $_POST['role'] ?? 'user';
        if (in_array($new_role, ['user', 'admin']) && $target_user_id > 0) {
            $upd = $pdo->prepare("UPDATE Users SET role = ? WHERE user_id = ?");
            $upd->execute([$new_role, $target_user_id]);
            $success = 'Пайдаланушы рөлі сәтті өзгертілді!';
        }
    } elseif ($action === 'delete_user') {
        $target_user_id = filter_var($_POST['user_id'] ?? 0, FILTER_VALIDATE_INT);
        if ($target_user_id > 0 && $target_user_id !== (int)current_user()['user_id']) {
            $pdo->prepare("DELETE FROM Users WHERE user_id = ?")->execute([$target_user_id]);
            $success = 'Пайдаланушы жүйеден өшірілді.';
        } else {
            $errors[] = 'Өз аккаунтіңізді өшіре алмайсыз.';
        }
    }
}

$users = $pdo->query("SELECT user_id, full_name, email, role, created_at FROM Users ORDER BY user_id DESC")->fetchAll();
$places_count = (int)$pdo->query("SELECT COUNT(*) FROM Places")->fetchColumn();
$reviews_count = (int)$pdo->query("SELECT COUNT(*) FROM Reviews")->fetchColumn();

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">14-АПТА · ӘКІМШІ ПАНЕЛІ (ADMIN PANEL)</span>
        <h1>Жүйені басқару және рөлдер</h1>
        <p class="small-muted">Бұл панель тек `admin` рөлі бар қолданушыларға ғана қолжетімді.</p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $e): ?><div>• <?= h($e) ?></div><?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= h($success) ?></div>
    <?php endif; ?>

    <div class="cards-3" style="margin-bottom:24px;">
        <div class="info-card">
            <h3>Барлық қолданушылар</h3>
            <p style="font-size:28px;font-weight:800;color:#1d63dc;margin:6px 0;"><?= count($users) ?></p>
        </div>
        <div class="info-card">
            <h3>Барлық нысандар</h3>
            <p style="font-size:28px;font-weight:800;color:#13733c;margin:6px 0;"><?= $places_count ?></p>
        </div>
        <div class="info-card">
            <h3>Барлық пікірлер</h3>
            <p style="font-size:28px;font-weight:800;color:#9333ea;margin:6px 0;"><?= $reviews_count ?></p>
        </div>
    </div>

    <div class="places-column" style="padding:24px;">
        <h3>Қолданушылар тізімі мен рөлдерді басқару</h3>
        <table style="width:100%;border-collapse:collapse;margin-top:14px;font-size:14px;">
            <thead>
                <tr style="background:#f1f5f9;text-align:left;">
                    <th style="padding:10px;border-bottom:1px solid #cbd5e1;">ID</th>
                    <th style="padding:10px;border-bottom:1px solid #cbd5e1;">Аты-жөні</th>
                    <th style="padding:10px;border-bottom:1px solid #cbd5e1;">Email</th>
                    <th style="padding:10px;border-bottom:1px solid #cbd5e1;">Рөлі</th>
                    <th style="padding:10px;border-bottom:1px solid #cbd5e1;">Тіркелген уақыты</th>
                    <th style="padding:10px;border-bottom:1px solid #cbd5e1;text-align:right;">Әрекеттер</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td style="padding:10px;border-bottom:1px solid #e2e8f0;"><?= (int)$u['user_id'] ?></td>
                    <td style="padding:10px;border-bottom:1px solid #e2e8f0;"><strong><?= h($u['full_name']) ?></strong></td>
                    <td style="padding:10px;border-bottom:1px solid #e2e8f0;"><?= h($u['email']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid #e2e8f0;">
                        <form method="post" style="display:inline-flex;gap:6px;align-items:center;">
                            <input type="hidden" name="action" value="change_role">
                            <input type="hidden" name="user_id" value="<?= (int)$u['user_id'] ?>">
                            <select name="role" style="padding:4px 8px;font-size:12px;width:auto;">
                                <option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>user</option>
                                <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>admin</option>
                            </select>
                            <button type="submit" class="btn btn-outline btn-sm" style="padding:4px 8px;font-size:11px;">Жаңарту</button>
                        </form>
                    </td>
                    <td style="padding:10px;border-bottom:1px solid #e2e8f0;font-size:12px;color:#64748b;"><?= h($u['created_at']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid #e2e8f0;text-align:right;">
                        <?php if ((int)$u['user_id'] !== (int)current_user()['user_id']): ?>
                            <form method="post" style="display:inline;" onsubmit="return confirm('Бұл пайдаланушыны жоюды растайсыз ба?');">
                                <input type="hidden" name="action" value="delete_user">
                                <input type="hidden" name="user_id" value="<?= (int)$u['user_id'] ?>">
                                <button type="submit" class="btn btn-outline btn-sm" style="color:#dc2626;border-color:#fca5a5;padding:4px 8px;font-size:11px;">Жою</button>
                            </form>
                        <?php else: ?>
                            <span class="small-muted">(Сізсіз)</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'includes/footer.php'; ?>