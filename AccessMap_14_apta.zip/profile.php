<?php
require_once 'includes/functions.php';
require_login();
$user_id = current_user()['user_id'];

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $full_name = trim($_POST['full_name'] ?? '');
        if ($full_name === '' || mb_strlen($full_name) < 2) {
            $errors[] = 'Аты-жөніңізді дұрыс енгізіңіз.';
        } else {
            $upd = $pdo->prepare("UPDATE Users SET full_name = ? WHERE user_id = ?");
            $upd->execute([$full_name, $user_id]);
            $_SESSION['user']['full_name'] = $full_name;
            $success = 'Профиль деректері сәтті жаңартылды!';
        }
    } elseif ($action === 'upload_avatar') {
        $res = upload_image_safely('avatar_file');
        if ($res['success']) {
            if ($res['filename']) {
                $upd = $pdo->prepare("UPDATE Users SET avatar = ? WHERE user_id = ?");
                $upd->execute([$res['filename'], $user_id]);
                $_SESSION['user']['avatar'] = $res['filename'];
                $success = 'Аватар суреті сәтті жүктелді!';
            } else {
                $errors[] = 'Жүктеу үшін файл таңдалмады.';
            }
        } else {
            $errors[] = $res['error'];
        }
    }
}

$stmtU = $pdo->prepare("SELECT * FROM Users WHERE user_id = ?");
$stmtU->execute([$user_id]);
$current_db_user = $stmtU->fetch();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM Places WHERE created_by = ?");
$stmt->execute([$user_id]);
$my_places = (int)$stmt->fetchColumn();

$stmt2 = $pdo->prepare("SELECT COUNT(*) FROM Reviews WHERE user_id = ?");
$stmt2->execute([$user_id]);
$my_reviews = (int)$stmt2->fetchColumn();

include 'includes/header.php';
?>
<div class="container">
    <div class="page-intro">
        <span class="section-kicker">14-АПТА · ПРОФИЛЬ ЖӘНЕ ФАЙЛ ЖҮКТЕУ</span>
        <h1>Жеке кабинет: <?= h($current_db_user['full_name']) ?></h1>
        <p class="small-muted">Бұл бетте профильді өңдеуге және қауіпсіз аватар (сурет) жүктеуге болады.</p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $e): ?><div>• <?= h($e) ?></div><?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= h($success) ?></div>
    <?php endif; ?>

    <div class="cards-3">
        <div class="info-card" style="text-align:center;">
            <div style="margin-bottom:14px;">
                <?php 
                $avatar = $current_db_user['avatar'] ?: 'default_avatar.png';
                $avatar_path = file_exists(__DIR__ . '/uploads/' . $avatar) && $avatar !== 'default_avatar.png' ? 'uploads/' . h($avatar) : 'https://api.dicebear.com/7.x/avataaars/svg?seed=' . urlencode($current_db_user['email']);
                ?>
                <img src="<?= $avatar_path ?>" alt="Avatar" style="width:96px;height:96px;border-radius:50%;object-fit:cover;border:3px solid #1d63dc;">
            </div>
            <h3><?= h($current_db_user['full_name']) ?></h3>
            <p class="small-muted"><?= h($current_db_user['email']) ?></p>
            <p><span class="pill-badge"><?= h($current_db_user['role']) ?></span></p>

            <form method="post" enctype="multipart/form-data" class="stack-form" style="margin-top:16px;text-align:left;">
                <input type="hidden" name="action" value="upload_avatar">
                <label>Аватар суретін жүктеу (JPG, PNG, WEBP, max 2MB):</label>
                <input type="file" name="avatar_file" accept="image/jpeg,image/png,image/webp" required style="font-size:12px;">
                <button type="submit" class="btn btn-outline btn-sm btn-block" style="margin-top:6px;">Суретті жаңарту</button>
            </form>
        </div>

        <div class="info-card">
            <h3>Профильді өзгерту</h3>
            <form method="post" class="stack-form" style="margin-top:12px;">
                <input type="hidden" name="action" value="update_profile">
                <label>Аты-жөні</label>
                <input type="text" name="full_name" required value="<?= h($current_db_user['full_name']) ?>">
                <label>Email (өзгертілмейді)</label>
                <input type="email" disabled value="<?= h($current_db_user['email']) ?>">
                <button type="submit" class="btn btn-primary btn-block" style="margin-top:10px;">Сақтау</button>
            </form>
        </div>

        <div class="info-card">
            <h3>Статистика және рөл</h3>
            <p><strong>Қосқан нысандарыңыз:</strong> <?= $my_places ?></p>
            <p><strong>Жазған пікірлеріңіз:</strong> <?= $my_reviews ?></p>
            <p><strong>Тіркелген күні:</strong> <?= h($current_db_user['created_at']) ?></p>
            <?php if (is_admin()): ?>
                <div style="margin-top:16px;">
                    <a href="admin.php" class="btn btn-outline btn-sm btn-block" style="background:#fef3c7;color:#92400e;border-color:#fde68a;">⚙️ Әкімші панеліне өту</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>