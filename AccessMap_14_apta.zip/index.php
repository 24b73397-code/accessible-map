<?php
require_once 'includes/functions.php';
include 'includes/header.php';

$places_count = (int)$pdo->query("SELECT COUNT(*) FROM Places")->fetchColumn();
$users_count  = (int)$pdo->query("SELECT COUNT(*) FROM Users")->fetchColumn();
$reviews_count = (int)$pdo->query("SELECT COUNT(*) FROM Reviews")->fetchColumn();
?>
<div class="container">
    <section class="hero-grid">
        <div class="hero-text">
            <span class="pill-badge">🛡️ 14-АПТА · ҚОСЫМША ФУНКЦИЯЛАР ЖӘНЕ ҚАУІПСІЗДІК</span>
            <h1>Кешенді қауіпсіздік және <span class="text-blue">кеңейтілген функциялар</span></h1>
            <p class="lead">
                AccessMap жобасының 14-аптасында профильді басқару, аватар файлдарын қауіпсіз жүктеу (MIME тексеруі), әкімші панелі (Admin/User рөлдері), XSS қорғанысы (`htmlspecialchars`) және дайындалған сұраныстар (`Prepared Statements`) арқылы толық қауіпсіздік қамтамасыз етілді.
            </p>
            <div class="hero-actions">
                <a href="map.php" class="btn btn-primary">🗺️ Қауіпсіз каталог пен картаға өту</a>
                <?php if (is_logged_in()): ?>
                    <a href="profile.php" class="btn btn-outline">👤 Жеке кабинетті басқару</a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-outline">Тіркеліп бастау</a>
                <?php endif; ?>
            </div>
            <p class="muted-note">Жүйедегі тіркелген қолданушылар: <strong><?= $users_count ?></strong>, барлық нысандар: <strong><?= $places_count ?></strong>.</p>
        </div>
        <div class="hero-card-visual">
            <div class="map-preview-card">
                <div class="floating-tag tag-top">🔒 XSS & SQLi Protected</div>
                <div class="floating-tag tag-right">🖼️ Safe File Uploads</div>
                <div class="floating-tag tag-bottom">👑 Admin & User Roles</div>
                <div class="map-emoji">🛡️</div>
                <p class="small-muted">14-апта стандарттары</p>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>