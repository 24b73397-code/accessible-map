</main>
<footer class="site-footer">
    <div class="container footer-wrap">
        <div><strong>✦ AccessMap</strong> — Мүмкіндігі шектеулі жандарға арналған қолжетімді нысандар каталогы.</div>
        <div class="footer-note">14-апта: Қосымша функциялар және қауіпсіздік (XSS, SQL Injection, File Upload)</div>
    </div>
</footer>
</body>
</html>